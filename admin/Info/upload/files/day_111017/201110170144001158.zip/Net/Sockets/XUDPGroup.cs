﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Net;
using System.Net.Sockets;
using HuaBo.Net.Sockets.Base;
namespace HuaBo.Net.Sockets
{
	/// <summary>
	/// XUDPGroup是UDP组播的实现
	/// </summary>
	public class XUDPGroup : XUDP
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="XUDPGroup"/> class.
		/// </summary>
		/// <param name="info">The info.</param>
		public XUDPGroup(XConnectionInformation info) : base(info) { }
		/// <summary>
		/// Initializes a new instance of the <see cref="XUDPGroup"/> class.
		/// </summary>
		/// <param name="socket">The socket.</param>
		/// <param name="sendBufferSize">Size of the send buffer.</param>
		/// <param name="receiveBufferSize">Size of the receive buffer.</param>
		public XUDPGroup(Socket socket, int sendBufferSize, int receiveBufferSize) : base(socket, sendBufferSize, receiveBufferSize) { }
		/// <summary>
		/// 开始XSocket
		/// </summary>
		public override void Start()
		{
			_RemoteEndPoint = (EndPoint)new IPEndPoint(IPAddress.Any, 0);
			if (_Socket == null)
			{
				try
				{
					_Socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
					_Socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
					_Socket.Bind(new IPEndPoint(IPAddress.Any, _Information.GetEndPoint().Port));
					_Socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.AddMembership, new MulticastOption(_Information.GetEndPoint().Address, IPAddress.Any));
				}
				catch (Exception ex)
				{
					ErrorEvent(new XConnectionErrorEventArgs(this, ex));
				}
			}
			_Socket.SendBufferSize = _Information.SendBufferSize;
			_Socket.ReceiveBufferSize = _Information.RecevieBufferSize;
			ReceiveDataProcessing(null);
		}
		/// <summary>
		/// 停止XSocket
		/// </summary>
		public override void Stop()
		{
			_Socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.DropMembership, new MulticastOption(_Information.GetEndPoint().Address));
			base.Stop();
		}
		/// <summary>
		/// 发送数据
		/// </summary>
		/// <param name="data">二进制数据</param>
		public override void Send(byte[] data)
		{
			try
			{
				_Socket.SendTo(data, _Information.GetEndPoint());
			}
			catch (SocketException ex)
			{
				LostEvent(new XConnectionEventArgs(this));
				ErrorEvent(new XConnectionErrorEventArgs(this, ex));
			}
		}
	}
}
