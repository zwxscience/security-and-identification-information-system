﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HuaBo.Net.Sockets.Pipes
{
    /// <summary>
    /// XConnectionType枚举定义了XConnection的类型
    /// </summary>
    public enum PipeType
    {
        /// <summary>
        /// TCP服务
        /// </summary>
        TCP_SERVER,
        /// <summary>
        /// TCP客户端
        /// </summary>
        TCP_CLIENT,
        /// <summary>
        /// UDP
        /// </summary>
        UDP,
        /// <summary>
        /// UDP广播
        /// </summary>
        UDP_MULTICAST
    }
}
