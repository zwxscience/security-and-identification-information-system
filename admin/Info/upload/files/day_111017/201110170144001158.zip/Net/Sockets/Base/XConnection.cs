﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Net.Sockets;
using System.Net;
using System.Timers;
using HuaBo.Utils;
using HuaBo.Net.Sockets.Message;

namespace HuaBo.Net.Sockets.Base
{
    /// <summary>
    /// XConnections是IXConnection接口的实现，是所有具体连接的基础类
    /// </summary>
    public class XConnection : IXConnection
    {
        protected string _LocalAddress="";
        protected string _RemoteAddress="";

        /// <summary>
        /// 底层socket
        /// </summary>
        protected Socket _Socket;
        /// <summary>
        /// 接收到的数据
        /// </summary>
        protected byte[] Data;
        /// <summary>
        /// 消息解析器
        /// </summary>
        protected IMessageParser _MessageParser = new MessageParser();
        /// <summary>
        /// 异步接收消息回调
        /// </summary>
        protected AsyncCallback ReceiveCallBack;
        /// <summary>
        /// XConnection信息描述
        /// </summary>
        protected XConnectionInformation _Information;
        protected string _RemoteName;
        protected byte[] CrippledBytes;
        /// <summary>
        /// 心跳包计时器
        /// </summary>
        private Timer AliveTimer;
        /// <summary>
        /// 心跳包消息
        /// </summary>
        private static AliveMessage ALIVE_MESSAGE = new AliveMessage();

        /// <summary>
        /// 无参构造函数
        /// <see cref="XConnection"/>
        /// </summary>
        public XConnection() { }

        /// <summary>
        /// 根据XConnectionInformation创建连接 
        /// <see cref="XConnection"/> class.
        /// </summary>
        /// <param name="info">连接信息描述</param>
        public XConnection(XConnectionInformation info)
        {
            _Information = info;
            AliveTimer = new Timer(Convert.ToDouble(_Information.KeepAliveDelay));
            AliveTimer.Elapsed += new ElapsedEventHandler(AliveTimer_Elapsed);

            ReceiveCallBack = new AsyncCallback(ReceiveDataProcessing);
            Data = new byte[_Information.RecevieBufferSize];
        }

        /// <summary>
        /// 根据socket创建连接
        /// <p>此构造函数用于将已有socket连接包装为XConnection</p>
        /// </summary>
        /// <param name="socket">socket</param>
        /// <param name="type">XConnection类型</param>
        /// <param name="sendBufferSize">发送缓冲区域大小</param>
        /// <param name="receiveBufferSize">接收缓冲区域大小</param>
        /// <param name="KeepAlive">是否使用心跳包保持连接</param>
        /// <param name="keepAliveDelay">心跳包发送频率</param>
        /// <param name="ipAddress">要绑定或者连接的网络端点</param>
        public XConnection(Socket socket, string name, XConnectionType type, int sendBufferSize, int receiveBufferSize, bool KeepAlive, int keepAliveDelay, string ipAddress)
        {
            _Socket = socket;
            _Information = new XConnectionInformation();
            _Information.Name = name;
            _Information.Type = type;
            _Information.IPAddress = ipAddress;
            _Information.KeepAlive = KeepAlive;
            _Information.KeepAliveDelay = keepAliveDelay;
            _Information.SendBufferSize = sendBufferSize;
            _Information.RecevieBufferSize = receiveBufferSize;

            AliveTimer = new Timer(Convert.ToDouble(_Information.KeepAliveDelay));
            AliveTimer.Elapsed += new ElapsedEventHandler(AliveTimer_Elapsed);

            ReceiveCallBack = new AsyncCallback(ReceiveDataProcessing);
            Data = new byte[_Information.RecevieBufferSize];
        }

        /// <summary>
        /// 根据socket创建连接
        /// 此构造函数为XConnection(socket,sendBufferSize,receiveBufferSize,keepAlive,keepAliveDelay)的简化版默认开启发送心跳
        /// </summary>
        /// <param name="socket">socket</param>
        public XConnection(Socket socket) : this(socket, "", XConnectionType.TCP_CLIENT, 8192, 8192, true, 3000, StringConvert.ToString((IPEndPoint)socket.RemoteEndPoint)) { }

        /// <summary>
        /// 根据socket创建连接
        /// 此构造函数用于将socket服务接受进来的socket包装为XConnection
        /// </summary>
        /// <param name="socket">socket</param>
        /// <param name="sendBufferSize">发送缓冲区域大小</param>
        /// <param name="receiveBufferSize">接收缓冲区域大小</param>
        /// <param name="keepAlive">是否使用心跳包保持连接</param>
        /// <param name="keepAliveDelay">心跳包发送频率</param>
        public XConnection(Socket socket, string name, int sendBufferSize, int receiveBufferSize, bool keepAlive, int keepAliveDelay) : this(socket, name, XConnectionType.TCP_CLIENT, sendBufferSize, receiveBufferSize, keepAlive, keepAliveDelay, StringConvert.ToString((IPEndPoint)socket.RemoteEndPoint)) { }
        /// <summary>
        /// XConnection注册事件
        /// </summary>
        public event RegisterEventHandler OnRegister;
        /// <summary>
        /// XConnection连接事件
        /// </summary>
        public event XConnectionConnectedEventHandler OnConnect;
        /// <summary>
        /// XConnection连接异常事件
        /// </summary>
        public event XConnectionErrorEventHandler OnError;
        /// <summary>
        /// XConnection收到原始消息事件
        /// </summary>
        public event XConnectionReceiveEventHandler OnData;
        /// <summary>
        /// XConnection连接丢失事件
        /// </summary>
        public event XConntionLostEventHandler OnLost;
        /// <summary>
        /// XConnection收到二进制消息事件
        /// </summary>
        public event ByteMessageEventHandler OnByteMessage;
        /// <summary>
        /// XConnection收到XML消息事件
        /// </summary>
        public event XMLMessageEventHandler OnXMLMessage;
        /// <summary>
        /// XConnection收到心跳包消息事件
        /// </summary>
        public event AliveMessageEventHandler OnAliveMessage;
        /// <summary>
        /// XConnection收到字符串消息事件
        /// </summary>
        public event StringMessageEventHandler OnStringMessage;
        /// <summary>
        /// XConnection收到未能定义类型消息事件
        /// </summary>
        public event UnKownMessageEventHandler OnUnKownMessage;
        /// <summary>
        /// XConnection收到远程命令消息事件
        /// </summary>
        public event CommandMessageEventHandler OnCommandMessage;
        public event MessageParseErrorEventHandler OnMessageError;

        /// <summary>
        /// 用于创建XConnection的相关信息
        /// </summary>
        public XConnectionInformation Information
        {
            get { return _Information; }
        }
        /// <summary>
        /// IXConnection消息解析器
        /// </summary>
        public IMessageParser MessageParser
        {
            get { return _MessageParser; }
            set { _MessageParser = value; }
        }
        /// <summary>
        /// IXConnection包含的基础socket
        /// </summary>
        public Socket Connection
        {
            get { return _Socket; }
        }
        public string Name
        {
            get { return _Information.Name; }
        }

        /// <summary>
        /// 发送数据缓存区域大小
        /// </summary>
        public int SendBufferSize
        {
            get { return _Information.SendBufferSize; }
            set { _Information.SendBufferSize = value; if (_Socket != null) { _Socket.SendBufferSize = value; } }
        }
        /// <summary>
        /// 接收数据缓存区域大小
        /// </summary>
        public int ReceiveBufferSize
        {
            get { return _Information.RecevieBufferSize; }
            set { _Information.RecevieBufferSize = value; if (_Socket != null) { _Socket.ReceiveBufferSize = value; } }
        }
        /// <summary>
        /// 获取本地网络端点
        /// </summary>
        /// <value>EndPoint</value>
        public virtual EndPoint LocalEndPoint
        {
            get { if (_Socket == null)return null; return _Socket.LocalEndPoint; }
        }
        public  string LocalAddress
        {
            get { if (LocalEndPoint != null) _LocalAddress = ((IPEndPoint)LocalEndPoint).ToString(); return _LocalAddress; }
        }
        /// <summary>
        /// 获取远程网络端点
        /// </summary>
        /// <value>EndPoint</value>
        public virtual EndPoint RemoteEndPoint
        {
          
            get { if(_Socket==null) return null; return _Socket.RemoteEndPoint; }
        }
        public string RemoteAddress
        {
            get { if (RemoteEndPoint != null)_RemoteAddress = ((IPEndPoint)RemoteEndPoint).ToString(); return _RemoteAddress; }
        }
        /// <summary>
        /// 指示是否已连接
        /// </summary>
        public bool Connected
        {
            get { if (_Socket == null)return false; return _Socket.Connected; }
        }
        /// <summary>
        /// 指示是否启用心跳包
        /// </summary>
        public bool KeepAlive
        {
            get { return _Information.KeepAlive; }
            set { _Information.KeepAlive = value; }
        }
        public string RemoteName
        {
            get { return _RemoteName; }
            set { _RemoteName = value; }
        }

        /// <summary>
        /// 心跳包发送时间间隔
        /// </summary>
        public int KeepAliveDelay
        {
            get { return _Information.KeepAliveDelay; }
            set { _Information.KeepAliveDelay = value; if (AliveTimer != null) { AliveTimer.Interval = Convert.ToDouble(value); } }
        }
        /// <summary>
        /// 发送数据
        /// </summary>
        /// <param name="data">二进制数据</param>
        public virtual void Send(byte[] data)
        {
            try
            {
                _Socket.Send(data);
            }
            catch (SocketException ex)
            {
                LostEvent(new XConnectionEventArgs(this));
                ErrorEvent(new XConnectionErrorEventArgs(this, ex));
            }
            catch (InvalidOperationException) { }
            //在每次使用Send发送数据后开始发送心跳消息
            StopKeepAlive();
            StartKeepAlive();
        }
        /// <summary>
        /// 发送数据到某一网络端点
        /// </summary>
        /// <param name="data">二进制数据</param>
        /// <param name="endPoint">网络端点</param>
        public virtual void Send(byte[] data, IPEndPoint endPoint)
        {
            try
            {
                _Socket.SendTo(data, (EndPoint)endPoint);
            }
            catch (SocketException ex)
            {
                LostEvent(new XConnectionEventArgs(this));
                ErrorEvent(new XConnectionErrorEventArgs(this, ex));
            }
            //在每次使用Send发送数据后开始发送心跳消息
            StopKeepAlive();
            StartKeepAlive();
        }
        /// <summary>
        /// 发送数据
        /// </summary>
        /// <param name="msg">IMessage类型消息</param>
        public virtual void Send(IMessage msg)
        {
            _Socket.SendBufferSize = msg.Bytes.Length;
            Send(msg.Bytes);
            _Socket.SendBufferSize = _Information.SendBufferSize;
        }
        /// <summary>
        /// 发送数据到某一网络端点
        /// </summary>
        /// <param name="msg">IMessage类型消息</param>
        /// <param name="endPoint">网络端点</param>
        public virtual void Send(IMessage msg, IPEndPoint endPoint)
        {
            _Socket.SendBufferSize = msg.Bytes.Length;
            Send(msg.Bytes, endPoint);
            _Socket.SendBufferSize = _Information.SendBufferSize;
        }
        public virtual void Send(byte[] data, string name)
        {
            Send(data);
        }
        /// <summary>
        /// 开始XSocket
        /// </summary>
        public virtual void Start()
        {
            CrippledBytes = null;
            StopKeepAlive();
            StartKeepAlive();
        }

        /// <summary>
        /// 停止XSocket
        /// </summary>
        public virtual void Stop()
        {
            StopKeepAlive();
            if (_Socket != null&&_Socket.Connected)
            {
                try
                {
                    _Socket.Shutdown(SocketShutdown.Both);
                    
                }
                catch (Exception) { }
              
            }
           
            try
            {
                _Socket.Close();
            }
            catch (Exception) { }
            CrippledBytes = null;
            _Socket = null;
        }
        /// <summary>
        /// 销毁
        /// </summary>
        public virtual void Dispose()
        {
            Stop();
            _Socket = null;
            if (AliveTimer != null)
            {
                AliveTimer.Stop();
                AliveTimer.Elapsed -= new ElapsedEventHandler(AliveTimer_Elapsed);
                AliveTimer.Close();
            }
            Console.WriteLine("销毁心跳计时器");
            AliveTimer = null;
        }

        /// <summary>
        /// 异步接收消息
        /// </summary>
        /// <param name="iar">异步操作对象</param>
        protected virtual void ReceiveDataProcessing(IAsyncResult iar)
        {
            if (Data.Length != _Information.RecevieBufferSize)
            {
                Data = new byte[_Information.RecevieBufferSize];
            }
        }
        /// <summary>
        /// 心跳包计时器事件
        /// </summary>
        /// <param name="sender">事件源</param>
        /// <param name="e">事件参数</param>
        protected void AliveTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (_Socket == null || !_Socket.Connected) return;

            try
            {
                _Socket.SendBufferSize = ALIVE_MESSAGE.Bytes.Length;
                //TCP协议使用_SocketSend发送心跳，UDP协议使用_Scoket.SendTo发送心跳
                if (_Information.Type == XConnectionType.TCP_CLIENT || _Information.Type == XConnectionType.TCP_SERVER)
                {
                    _Socket.Send(ALIVE_MESSAGE.Bytes);
                }
                else
                {
                    _Socket.SendTo(ALIVE_MESSAGE.Bytes, RemoteEndPoint);
                }
                _Socket.SendBufferSize = _Information.SendBufferSize;
            }

            catch (SocketException ex)
            {
                LostEvent(new XConnectionEventArgs(this));
                ErrorEvent(new XConnectionErrorEventArgs(this, ex));
            }
            catch (Exception) { }
           
        }

        /// <summary>
        /// 开始尝试发送心跳包
        /// </summary>
        protected void StartKeepAlive()
        {
            if (AliveTimer != null && _Information.KeepAlive && !AliveTimer.Enabled)
            {
                AliveTimer.Enabled = true;
            }
        }

        /// <summary>
        /// 停止发送心跳包
        /// </summary>
        protected void StopKeepAlive()
        {
            if (AliveTimer != null)
            {
                AliveTimer.Enabled = false;
            }
        }

        /// <summary>
        /// 发送所有可识别的消息事件
        /// 对于具有特定消息的子类需要重载此方法以添加特定消息事件的识别
        /// </summary>
        /// <param name="xe">XConnection事件参数
        /// <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/>
        /// </param>
        /// <param name="msg">消息</param>
        /// <returns>如果接收到的数据可转换为可识别消息则返回true否则返回false</returns>
        protected virtual bool DispatchKownMessageEvent(XConnectionEventArgs xe, IMessage msg)
        {
            bool isUnKownMessage = true;
            switch (msg.Type)
            {
                case MessageType.STRING:
                    StringMessageEvent(xe, msg as StringMessage);
                    isUnKownMessage = false;
                    break;
                case MessageType.COMMAND:
                    CommandMessageEvent(xe, msg as CommandMessage);
                    isUnKownMessage = false;
                    break;
                case MessageType.BYTE:
                    ByteMessageEvent(xe, msg as ByteMessage);
                    isUnKownMessage = false;
                    break;
                case MessageType.ALIVE:
                    AliveMessageEvent(xe, msg as AliveMessage);
                    isUnKownMessage = false;
                    break;
            }
            return (!isUnKownMessage);
        }

        /// <summary>
        /// 发送所有消息事件
        /// </summary>
        /// <param name="data">接收到的原始二进制数据</param>
        protected void DispatchMessageEvent(byte[] data)
        {

            byte[] buffer;
            if(CrippledBytes==null){
                buffer = new byte[data.Length];
                Array.Copy(data, buffer, data.Length);
            }else{
                Console.WriteLine("上次接受到残缺消息{0}", CrippledBytes.Length);
            buffer = new byte[data.Length + CrippledBytes.Length];
            Array.Copy(CrippledBytes, buffer, CrippledBytes.Length);
            Array.Copy(data, 0, buffer, CrippledBytes.Length, data.Length);
            }
            CrippledBytes = ParseMsg(buffer);
        }

        private byte[] ParseMsg(byte[] data)
        {
            byte[] less;
            IMessage msg;
            try
            {
                 msg = MessageParser.Parse(data);
            }
            catch (MessageParseException ex)
            {
                less = new byte[data.Length];
                Array.Copy(data, 0, less, 0, data.Length);
                Console.WriteLine("消息解析出错！！");
                return less;
            }
            Console.WriteLine(msg + "===========");
            if (msg != null)
            {
                XConnectionEventArgs xe = new XConnectionEventArgs(this);
                if (!DispatchKownMessageEvent(xe, msg))
                {
                    UnKownMessageEvent(xe, msg as UnKownMessage);
                }
                long lessLen = data.Length - msg.Bytes.Length;
                if (lessLen == 0)
                {
                    return null;
                }
                else
                {
                    less = new byte[lessLen];
                    Array.Copy(data, msg.Bytes.Length, less, 0, lessLen);
                    return ParseMsg(less);
                }
            }
            return null;
        }
        /// <summary>
        /// 发送连接事件
        /// </summary>
        /// <param name="xe">XConnection事件参数
        /// <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/>
        /// </param>
        protected void ConnectEvent(XConnectionEventArgs xe)
        {
            if (OnConnect != null)
            {
                OnConnect(this, xe);
            }
        }
        /// <summary>
        /// 发送异常事件
        /// </summary>
        /// <param name="xe">XConnection事件参数
        /// <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/>
        /// </param>
        protected void ErrorEvent(XConnectionErrorEventArgs xe)
        {
            if (OnError != null)
            {
                OnError(this, xe);
            }
        }
        /// <summary>
        /// 发送接收数据事件
        /// </summary>
        /// <param name="xe">XConnection事件参数
        /// <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/>
        /// </param>
        protected void ReceiveEvent(XConnectionReceiveEventArgs xe)
        {
            if (OnData != null)
            {
                OnData(this, xe);
            }
        }
        protected void MessageErrorEvent(MessageParseException ex)
        {
            if (OnMessageError != null)
                OnMessageError(this, ex);
        }
        protected void RegisterEvent(XConnectionEventArgs xe,string[] args)
        {
            if (OnRegister != null)
            {
               
                OnRegister(this, xe,args);
            }
        }
        /// <summary>
        /// 发送连接丢失事件
        /// </summary>
        /// <param name="xe">XConnection事件参数
        /// <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/>
        /// </param>
        protected void LostEvent(XConnectionEventArgs xe)
        {
            if (OnLost != null)
            {
                OnLost(this, xe);
            }
        }
        /// <summary>
        /// 发送ByteMessage事件
        /// </summary>
        /// <param name="xe">XConnection事件参数
        /// <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/>
        /// </param>
        /// <param name="msg">消息
        /// <see cref="HuaBo.Net.Sockets.Message.ByteMessage"/>
        /// </param>
        protected void ByteMessageEvent(XConnectionEventArgs xe, ByteMessage msg)
        {
            if (OnByteMessage != null)
            {
                OnByteMessage(this, xe, msg);
            }
        }
        /// <summary>
        /// 发送StringMessage事件
        /// </summary>
        /// <param name="xe">XConnection事件参数
        /// <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/>
        /// </param>
        /// <param name="msg">消息
        /// <see cref="HuaBo.Net.Sockets.Message.StringMessage"/>
        /// </param>
        protected void StringMessageEvent(XConnectionEventArgs xe, StringMessage msg)
        {
            if (OnStringMessage != null)
            {
                OnStringMessage(this, xe, msg);
            }
        }
        /// <summary>
        /// 发送XMLMessage事件
        /// </summary>
        /// <param name="xe">XConnection事件参数
        /// <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/>
        /// </param>
        /// <param name="msg">消息
        /// <see cref="HuaBo.Net.Sockets.Message.XMLMessage"/>
        /// </param>
        protected void XMLMessageEvent(XConnectionEventArgs xe, XMLMessage msg)
        {
            if (OnXMLMessage != null)
            {
                OnXMLMessage(this, xe, msg);
            }
        }
        /// <summary>
        /// 发送CommandMessage事件
        /// </summary>
        /// <param name="xe">XConnection事件参数
        /// <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/>
        /// </param>
        /// <param name="msg">消息
        /// <see cref="HuaBo.Net.Sockets.Message.CommandMessage"/>
        /// </param>
        protected void CommandMessageEvent(XConnectionEventArgs xe, CommandMessage msg)
        {
            Console.WriteLine(string.Format("{0}:{1}{2}",xe.Connection.RemoteEndPoint,msg.Option,string.Join(",",msg.Arguments)));
            if (msg.Option.ToLower() == "register")
            {
                xe.Connection.RemoteName = (msg.Arguments[0] + "");
                RegisterEvent(xe, msg.Arguments);
                return;
            }
           
            if (OnCommandMessage != null)
            {
                Console.WriteLine("COMMAND");
                OnCommandMessage(this, xe, msg);
            }
        }
        /// <summary>
        /// 发送UnKownMessage事件
        /// </summary>
        /// <param name="xe">XConnection事件参数
        /// <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/>
        /// </param>
        /// <param name="msg">消息
        /// <see cref="HuaBo.Net.Sockets.Message.UnKownMessage"/>
        /// </param>
        protected void UnKownMessageEvent(XConnectionEventArgs xe, UnKownMessage msg)
        {
           
            if (xe.Connection.RemoteName == null || xe.Connection.RemoteName == "")
            {
                string name;
                string msgStr = Encoding.UTF8.GetString(msg.Bytes);
                int index = msgStr.IndexOf("register|", 0, msgStr.Length, StringComparison.CurrentCultureIgnoreCase);
                if (index != -1)
                {
                    string param = msgStr.Substring(index + 9, msgStr.Length - (index + 9));
                   
                    string[] args = param.Split(',');
                   
                    xe.Connection.RemoteName=(args[0]);
                
                    RegisterEvent(xe,args);
                    return;
                }

                msgStr = Encoding.ASCII.GetString(msg.Bytes);
                index = msgStr.IndexOf("register|", 0, msgStr.Length, StringComparison.CurrentCultureIgnoreCase);

                if (index != -1)
                {
                    string param = msgStr.Substring(index + 9, msgStr.Length - (index + 9));

                    string[] args = param.Split(',');

                    xe.Connection.RemoteName = (args[0]);

                    RegisterEvent(xe, args);
                    return;
                }
            }
            if (OnUnKownMessage != null)
            {
              
                OnUnKownMessage(this, xe, msg);
            }
        }
        /// <summary>
        /// 发送AliveMessage事件
        /// </summary>
        /// <param name="xe">XConnection事件参数
        /// <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/>
        /// </param>
        /// <param name="msg">消息
        /// <see cref="HuaBo.Net.Sockets.Message.AliveMessage"/>
        /// </param>
        protected void AliveMessageEvent(XConnectionEventArgs xe, AliveMessage msg)
        {
            if (OnAliveMessage != null)
            {
                OnAliveMessage(this, xe, msg);
            }
        }
    }
}

