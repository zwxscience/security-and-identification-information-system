﻿using System;
using System.Collections.Generic;

using System.Text;

namespace HuaBo.Net.Sockets.Message
{
	/// <summary>
	/// ByteMessage表示二进制数据消息
	/// 其结构为：消息类型(1byte)+消息编号(4byte)+消息长度(4byte)+消息内容
	/// 一般此消息用于传输文件
	/// </summary>
	public class ByteMessage : AbstractMessage
	{
		/// <summary>
		/// 消息编号
		/// </summary>
		protected int _index;
		/// <summary>
		/// 消息长度
		/// </summary>
		protected int _length;
		/// <summary>
		/// 消息内容
		/// </summary>
		protected byte[] _data;
		/// <summary>
		/// 消息编号
		/// </summary>
		public int Index
		{
			get { return _index; }
		}
		/// <summary>
		/// 消息长度
		/// 此长度指示实际可用内容的长度
		/// </summary>
		public int Length
		{
			get { return _length; }
		}
		/// <summary>
		/// 消息内容
		/// </summary>
		public byte[] Data
		{
			get { return _data; }
		}
		/// <summary>
		/// 从二进制数据创建Byte消息
		/// 此构造函数用于将socket接受到的数据转换为Byte消息
		/// </summary>
		/// <param name="data">二进制数据</param>
		public ByteMessage(byte[] data)
			: this(data, -1)
		{

		}
		/// <summary>
		/// 从二进制数据创建Byte消息
		/// </summary>
		/// <param name="data">二进制数据</param>
		/// <param name="index">消息编号</param>
		public ByteMessage(byte[] data, int index)
		{
			_type = MessageType.BYTE;
			_index = index;

			if (_index!=-1)
			{
				_data = data;
				_length = data.Length;
				_bytes = new byte[1 + 4 + 4 + _length];
				byte[] lenByte = BitConverter.GetBytes(_length);
				byte[] indexByte = BitConverter.GetBytes(_index);
				_bytes[0] = MessageType.BYTE;
				Array.Copy(indexByte, 0, _bytes, 1, indexByte.Length);
				Array.Copy(lenByte, 0, _bytes, 5, lenByte.Length);
				Array.Copy(data, 0, _bytes, 9, data.Length);
			}
			else
			{
				_bytes = data;
				_index = BitConverter.ToInt32(_bytes, 1);
				_length = BitConverter.ToInt32(_bytes, 5);
                ////TODO应该是建立一个数据缓存来读消息，不应该做长度判断
                //if (_bytes.Length != _length + 9)
                //{
                    
                //    Console.WriteLine("应需要{0},实际消息长度{1}", _length + 9, _bytes.Length);
                    
                //}
				_data = new byte[_length];
				Array.Copy(_bytes, 9, _data, 0, _data.Length);
			}
			_value = _data;
		}
	}


}
