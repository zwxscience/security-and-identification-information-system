﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Net.Sockets;
namespace HuaBo.Net.Sockets.Base
{
	/// <summary>
	/// XConnection错误事件描述
	/// </summary>
	public class XConnectionErrorEventArgs : XConnectionEventArgs
	{
		/// <summary>
		/// SocketException
		/// </summary>
		private Exception _exception;
		/// <summary>
		/// 获取发生的异常
		/// </summary>
		/// <value>SocketException</value>
		public Exception Exception
		{
			get
			{
				return _exception;
			}
		}
		/// <summary>
		/// XConnectionErrorEventArgs构造函数
		/// <see cref="XConnectionErrorEventArgs"/>
		/// </summary>
		/// <param name="conn">发生异常的IXConnection实例</param>
		/// <param name="ex">发生的异常</param>
		public XConnectionErrorEventArgs(IXConnection conn, Exception ex)
			: base(conn)
		{
			_exception = ex;
		}
	}
}
