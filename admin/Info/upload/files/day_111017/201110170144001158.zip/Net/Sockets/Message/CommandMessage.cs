﻿using System;
using System.Collections.Generic;

using System.Text;

namespace HuaBo.Net.Sockets.Message
{
    /// <summary>
    /// CommandMessage表示远程命令消息
    /// 其结构为：消息类型(1byte)+消息编码(1byte)+消息长度(4byte)+消息内容 
    /// </summary>
    public class CommandMessage : StringMessage
    {
		/// <summary>
		/// 操作
		/// </summary>
        protected string _option;
		/// <summary>
		/// 参数
		/// </summary>
        protected string[] _arguments;
		/// <summary>
		/// 操作参数分隔符
		/// </summary>
        private string optionSign = "|";
		/// <summary>
		/// 参数分隔符
		/// </summary>
        private string argumentsSign = ",";
		/// <summary>
		/// 操作参数分隔符替换字符
		/// </summary>
        private string optionSignReplace = "*BROKEN*";
		/// <summary>
		/// 参数分隔符替换字符
		/// </summary>
        private string argumentsSignReplace = "*DOT*";
        /// <summary>
        /// 远程命令要调用的操作
        /// </summary>
        public string Option
        {
            get { return _option; }
        }
        /// <summary>
        /// 远程命令的参数
        /// </summary>
        public string[] Arguments
        {
            get { return _arguments; }
        }
        /// <summary>
        /// 从二进制数据创建远程命令消息
        /// 此构造函数用于将socket接受到的数据转换为远程命令消息
        /// </summary>
        /// <param name="data">二进制数据</param>
        public CommandMessage(byte[] data)
          
        {
            _type = MessageType.COMMAND;
            ParseByteToString(data);
            string[] Arr = _message.Split(new char[] { '|' });
            _option = unReplaceSign(Arr[0]);
            if (Arr[1] == "null")
            {
                _arguments = null;
            }
            else
            {
                _arguments = Arr[1].Split(new char[] { ',' });
                for (int i = 0; i < _arguments.Length; i++)
                {
                    _arguments[i] = unReplaceSign(_arguments[i]);
                }
            }
        }
        /// <summary>
        /// 按给定的操作和参数创建远程命令消息
        /// </summary>
        /// <param name="option">操作</param>
        /// <param name="encode">编码</param>
        /// <param name="args">参数</param>
        public CommandMessage(string option, MessageEncoding encode, params object[] args)
        {
            _type = MessageType.COMMAND;
            _option = option;
            string replaceResult = ReplaceSign(option) + optionSign;
            if (args == null)
            {
                _arguments = null;
                replaceResult += "null";
            }
            else
            {
                _arguments = new string[args.Length];
                for (int i = 0; i < args.Length; i++)
                {
                    _arguments[i] = args[i].ToString();
                    replaceResult += (i == args.Length - 1) ? ReplaceSign(_arguments[i]) : ReplaceSign(_arguments[i]) + argumentsSign;
                }
            }
            ParseStringToByte(replaceResult, encode);
        }
        /// <summary>
        /// 按给定的操作和参数创建远程命令消息
        /// 默认使用utf-8对消息进行编码
        /// </summary>
        /// <param name="option">操作</param>
        /// <param name="args">参数</param>
        public CommandMessage(string option, params object[] args)
            : this(option, MessageEncoding.UTF8, args)
        {

        }

		/// <summary>
		/// 替换分割符
		/// </summary>
		/// <param name="msg">消息</param>
		/// <returns></returns>
        protected string ReplaceSign(string msg)
        {
            return msg.Replace(optionSign, optionSignReplace).Replace(argumentsSign, argumentsSignReplace);
        }
		/// <summary>
		/// 还原分隔符
		/// </summary>
		/// <param name="msg">消息</param>
		/// <returns></returns>
        protected string unReplaceSign(string msg)
        {
            return msg.Replace(optionSignReplace, optionSign).Replace(argumentsSignReplace, argumentsSign);
        }
    }
}
