﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HuaBo.Net.Sockets.Pipes
{
    public class PipeErrorEventArgs:PipeEventArgs
    {
        private Exception _excption;
        public Exception Excption { get { return _excption; } }
        public PipeErrorEventArgs(IPipe pipe, Exception ex):base(pipe)
        {
            _excption = ex;
        }
    }
}
