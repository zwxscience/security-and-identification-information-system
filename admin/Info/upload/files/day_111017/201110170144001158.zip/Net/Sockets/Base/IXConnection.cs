﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Net.Sockets;
using System.Net;
using HuaBo.Net.Sockets.Message;
/// <summary>
/// HuaBo.Net.Sockets.Base命名空间包含一系列socket通讯的抽象类和接口
/// </summary>
namespace HuaBo.Net.Sockets.Base
{
	/// <summary>
	/// IXConnection定义了socket连接的创建和基本读写操作
	/// </summary>
	public interface IXConnection : IDisposable
	{
        /// <summary>
        /// XConnection注册事件
        /// </summary>
        event RegisterEventHandler OnRegister;
		/// <summary>
		/// XConnection连接事件
		/// </summary>
		event XConnectionConnectedEventHandler OnConnect;
		/// <summary>
		/// Occurs when [on message error].
		/// </summary>
		event MessageParseErrorEventHandler OnMessageError;
		/// <summary>
		/// XConnection连接异常事件
		/// </summary>
		event XConnectionErrorEventHandler OnError;
		/// <summary>
		/// XConnection收到原始消息事件
		/// </summary>
		event XConnectionReceiveEventHandler OnData;
		/// <summary>
		/// XConnection连接丢失事件
		/// </summary>
		event XConntionLostEventHandler OnLost;
		/// <summary>
		/// XConnection收到二进制消息事件
		/// </summary>
		event ByteMessageEventHandler OnByteMessage;
		/// <summary>
		/// XConnection收到XML消息事件
		/// </summary>
		event XMLMessageEventHandler OnXMLMessage;
		/// <summary>
		/// XConnection收到心跳包消息事件
		/// </summary>
		event AliveMessageEventHandler OnAliveMessage;
		/// <summary>
		/// XConnection收到字符串消息事件
		/// </summary>
		event StringMessageEventHandler OnStringMessage;
		/// <summary>
		/// XConnection收到未能定义类型消息事件
		/// </summary>
		event UnKownMessageEventHandler OnUnKownMessage;
		/// <summary>
		/// XConnection收到远程命令消息事件
		/// </summary>
		event CommandMessageEventHandler OnCommandMessage;


		/// <summary>
		/// 用于创建XConnection的相关信息
		/// </summary>
		XConnectionInformation Information { get; }
		/// <summary>
		/// IXConnection消息解析器
		/// </summary>
		IMessageParser MessageParser { get; set; }
        /// <summary>
        /// 注册使用的名字
        /// </summary>
        string Name { get; }
        string RemoteName { get; set; }
		/// <summary>
		/// IXConnection包含的基础socket
		/// </summary>
		Socket Connection { get; }
		/// <summary>
		/// 发送数据缓存区域大小
		/// </summary>
		int SendBufferSize { get; set; }
		/// <summary>
		/// 接收数据缓存区域大小
		/// </summary>
		int ReceiveBufferSize { get; set; }
		/// <summary>
		/// 获取本地网络端点
		/// </summary>
		/// <value>EndPoint</value>
		EndPoint LocalEndPoint { get; }
		/// <summary>
		/// 获取远程网络端点
		/// </summary>
		/// <value>EndPoint</value>
		EndPoint RemoteEndPoint { get; }
        string LocalAddress { get; }
        string RemoteAddress { get; }
		/// <summary>
		/// 指示是否已连接
		/// </summary>
		bool Connected { get; }
		/// <summary>
		/// 指示是否启用心跳包
		/// </summary>
		bool KeepAlive { get; set; }
		/// <summary>
		/// 心跳包发送时间间隔
		/// </summary>
		int KeepAliveDelay { get; set; }
		/// <summary>
		/// 发送数据
		/// </summary>
		/// <param name="data">二进制数据</param>
		void Send(byte[] data);
		/// <summary>
		/// 发送数据到某一网络端点
		/// </summary>
		/// <param name="data">二进制数据</param>
		/// <param name="endPoint">网络端点</param>
		void Send(byte[] data, IPEndPoint endPoint);
		/// <summary>
		/// 发送数据
		/// </summary>
		/// <param name="msg">IMessage类型消息</param>
		void Send(IMessage msg);
		/// <summary>
		/// 发送数据到某一网络端点
		/// </summary>
		/// <param name="msg">IMessage类型消息</param>
		/// <param name="endPoint">网络端点</param>
		void Send(IMessage msg, IPEndPoint endPoint);
        /// <summary>
        /// 发送数据到某一网络端点
        /// </summary>
        /// <param name="data">二进制数据</param>
        /// <param name="string">网络端点注册的名称</param>
        void Send(byte[] data, string name);
		/// <summary>
		/// 开始XSocket
		/// </summary>
		void Start();

		/// <summary>
		/// 停止XSocket
		/// </summary>
		void Stop();
	}
}
