﻿using System;
using System.Collections.Generic;

using System.Text;
using HuaBo.Net.Sockets.Base;
namespace HuaBo.Net.Sockets
{
	/// <summary>
	/// XConnectionFactory是创建XConnection类型对象的工厂方法实现
	/// </summary>
    public class XConnectionFactory
    {
        /// <summary>
        /// 根据指定的连接信息创建连接
        /// </summary>
        /// <param name="info">The info.</param>
        /// <returns></returns>
        public static IXConnection Create(XConnectionInformation info) {
			IXConnection connection = null;
			switch(info.Type){
				case XConnectionType.TCP_CLIENT:
					connection = new XClient(info);
					break;
				case XConnectionType.TCP_SERVER:
					connection = new XServer(info);
					break;
				case XConnectionType.UDP:
					connection = new XUDP(info);
					break;
				case XConnectionType.UDP_MULTICAST:
					connection = new XUDPGroup(info);
					break;
			}
			return connection;
		}
    }
}
