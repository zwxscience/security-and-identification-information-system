﻿using System;
using System.Collections.Generic;

using System.Text;

namespace HuaBo.Net.Sockets.Message
{
	/// <summary>
	/// StringMessage表示文本类型的消息
	/// 其结构为：消息类型(1byte)+消息编码(1byte)+消息长度(4byte)+消息内容
	/// </summary>
	public class StringMessage : AbstractMessage
	{

		/// <summary>
		/// 消息编码
		/// </summary>
		protected MessageEncoding _encode;
		/// <summary>
		/// 消息内容
		/// </summary>
		protected string _message;
		/// <summary>
		/// 消息编码
		/// </summary>
		public MessageEncoding Encode
		{
			get { return _encode; }
		}
		/// <summary>
		/// 消息内容
		/// </summary>
		public string Message
		{
			get { return _message; }
		}
		public StringMessage() { }
		/// <summary>
		/// 从二进制数据创建文本消息
		/// 此构造函数用于将socket接受到的数据转换为文本消息
		/// </summary>
		/// <param name="data">二进制数据</param>
		public StringMessage(byte[] data)
		{
			_type = MessageType.STRING;
			ParseByteToString(data);
		}
		/// <summary>
		/// 从字符串按指定编码创建文本消息
		/// </summary>
		/// <param name="msg">字符串</param>
		/// <param name="encode">编码</param>
		public StringMessage(string msg, MessageEncoding encode)
		{
			_type = MessageType.STRING;
			ParseStringToByte(msg, encode);
		}

		/// <summary>
		/// 将接收到的数据转换为文本消息
		/// </summary>
		/// <param name="data">接收到的数据</param>
		protected void ParseByteToString(byte[] data)
		{
			_bytes = data;
			_encode = (MessageEncoding)_bytes[1];
			int len = BitConverter.ToInt32(_bytes, 2);
			byte[] msgByte = new byte[len];
			Array.Copy(_bytes, 6, msgByte, 0, msgByte.Length);
			switch (_encode)
			{
				case MessageEncoding.Default:
					_message = Encoding.Default.GetString(msgByte);
					break;
				case MessageEncoding.UTF8:
					_message = Encoding.UTF8.GetString(msgByte);
					break;
				case MessageEncoding.ASCII:
					_message = Encoding.ASCII.GetString(msgByte);
					break;
				case MessageEncoding.Unicode:
					_message = Encoding.Unicode.GetString(msgByte);
					break;
			}
			_value = _message;
		}
		/// <summary>
		/// 将文本按指定编码转换为二进制数据
		/// </summary>
		/// <param name="msg">文本内容</param>
		/// <param name="encode">编码</param>
		protected void ParseStringToByte(string msg, MessageEncoding encode)
		{
			_value = msg;
			_message = msg;
			_encode = encode;
			byte[] data = new byte[0];
			switch (encode)
			{
				case MessageEncoding.Default:
					data = Encoding.Default.GetBytes(msg);
					break;
				case MessageEncoding.UTF8:
					data = Encoding.UTF8.GetBytes(msg);
					break;
				case MessageEncoding.ASCII:
					data = Encoding.ASCII.GetBytes(msg);
					break;
				case MessageEncoding.Unicode:
					data = Encoding.Unicode.GetBytes(msg);
					break;
				default:
					_bytes = new byte[0];
					return;
			}
			int len = data.Length;
			_bytes = new byte[1 + 1 + 4 + len];
			_bytes[0] = _type;
			_bytes[1] = (byte)encode;
			byte[] lenByte = BitConverter.GetBytes(len);
			System.Array.Copy(lenByte, 0, _bytes, 2, lenByte.Length);
			System.Array.Copy(data, 0, _bytes, 6, data.Length);
		}

	}
}
