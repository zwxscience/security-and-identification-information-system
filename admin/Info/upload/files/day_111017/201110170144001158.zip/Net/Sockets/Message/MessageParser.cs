﻿using System;
using System.Collections.Generic;

using System.Text;

namespace HuaBo.Net.Sockets.Message
{
	/// <summary>
	///MessageParser为消息解析器的默认实现
	/// </summary>
	public class MessageParser : IMessageParser
	{
		/// <summary>
		/// 从2进制创建消息
		/// </summary>
		///<param name="data">二进制数据</param>
		public IMessage Parse(byte[] data)
		{
			byte type = data[0];
			try
			{
				switch (type)
				{
					case MessageType.ALIVE:
						return new AliveMessage();
					case MessageType.BYTE:
						return new ByteMessage(data);
					case MessageType.COMMAND:
						return new CommandMessage(data);
					case MessageType.STRING:
						return new StringMessage(data);
					case MessageType.XML:
						return new XMLMessage(data);
					default:
						return new UnKownMessage(data);
				}
			}
			catch (Exception ex)
			{
				throw new MessageParseException(type, "解析消息出错!\r\n"+ex.ToString());
			}
		}


	}
}
