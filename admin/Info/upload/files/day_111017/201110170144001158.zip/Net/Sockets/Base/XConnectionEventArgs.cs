﻿using System;
using System.Collections.Generic;

using System.Text;

namespace HuaBo.Net.Sockets.Base
{
	/// <summary>
	/// XConnection事件描述基础类
	/// </summary>
	public class XConnectionEventArgs : EventArgs
	{
		/// <summary>
		/// IXConnection实例
		/// </summary>
		private IXConnection _connection;
		/// <summary>
		/// 获取IXConnection实例
		/// </summary>
		/// <value>IXConnection</value>
		public IXConnection Connection
		{
			get
			{
				return _connection;
			}
		}
		/// <summary>
		/// 构造函数
		/// <see cref="XConnectionEventArgs"/>
		/// </summary>
		/// <param name="conn">IXConnection实例</param>
		public XConnectionEventArgs(IXConnection conn)
		{
			_connection = conn;
		}
	}
}
