﻿using System;
using System.Collections.Generic;

using System.Text;

namespace HuaBo.Net.Sockets.Base
{
	/// <summary>
	/// XConnection接收数据事件描述
	/// </summary>
	public class XConnectionReceiveEventArgs : XConnectionEventArgs
	{
		/// <summary>
		/// XConnection收到的数据
		/// </summary>
		private byte[] _data;
		/// <summary>
		/// 获取XConnection收到的数据
		/// </summary>
		/// <value>byte[]</value>
		public byte[] Data
		{
			get
			{
				return _data;
			}
		}
		/// <summary>
		/// 构造函数
		/// <see cref="XConnectionReceiveEventArgs"/>
		/// </summary>
		/// <param name="conn">接收到数据的IXConnection实例</param>
		/// <param name="data">接收到的数据</param>
		public XConnectionReceiveEventArgs(IXConnection conn, byte[] data)
			: base(conn)
		{
			_data = data;
		}
	}
}
