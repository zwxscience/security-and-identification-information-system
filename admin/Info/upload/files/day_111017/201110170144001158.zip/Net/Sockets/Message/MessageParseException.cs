﻿using System;
using System.Collections.Generic;

using System.Text;
using HuaBo.Net.Sockets.Message;
namespace HuaBo.Net.Sockets.Message
{
	public class MessageParseException : Exception
	{
		private byte _Type;

		public MessageParseException(byte type, string msg)
			: base(msg)
		{
			_Type = type;
		}

		public byte Type { get { return _Type; } }
	}
}
