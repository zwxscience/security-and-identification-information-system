﻿using System;
using System.Collections.Generic;

using System.Text;
using HuaBo.Net.Sockets.Message;

namespace HuaBo.Net.Sockets.Base
{
	/// <summary>
	/// XConnection异常处理代理
	/// </summary>
	/// <param name="sender">事件源</param>
	/// <param name="xe">XConnection错误描述</param>
	public delegate void XConnectionErrorEventHandler(object sender, XConnectionErrorEventArgs xe);
	/// <summary>
	/// XConnection数据处理代理
	/// </summary>
	/// <param name="sender">事件源</param>
	/// <param name="xe">XConnection接收数据描述</param>
	public delegate void XConnectionReceiveEventHandler(object sender, XConnectionReceiveEventArgs xe);
	/// <summary>
	/// XConnection连接成功处理代理
	/// </summary>
	/// <param name="sender">事件源</param>
	/// <param name="xe">XConnction连接成功描述</param>
	public delegate void XConnectionConnectedEventHandler(object sender, XConnectionEventArgs xe);
	/// <summary>
	/// XConnection连接丢失处理代理
	/// </summary>
	/// <param name="sender">事件源</param>
	/// <param name="xe">XConnection连接丢失描述</param>
	public delegate void XConntionLostEventHandler(object sender, XConnectionEventArgs xe);

	public delegate void MessageParseErrorEventHandler(object sender,MessageParseException ex);
	/// <summary>
	/// 心跳包消息事件代理
	/// </summary>
	/// <param name="sender">事件源</param>
	/// <param name="xe">事件参数</param>
	/// <param name="msg">心跳包消息</param>
	public delegate void AliveMessageEventHandler(object sender, XConnectionEventArgs xe, AliveMessage msg);
	/// <summary>
	/// 文本消息事件代理
	/// </summary>
	/// <param name="sender">事件源</param>
	/// <param name="xe">事件参数</param>
	/// <param name="msg">文本消息</param>
	public delegate void StringMessageEventHandler(object sender, XConnectionEventArgs xe, StringMessage msg);
	/// <summary>
	/// 二进制消息事件代理
	/// </summary>
	/// <param name="sender">事件源</param>
	/// <param name="xe">事件参数</param>
	/// <param name="msg">二进制消息</param>
	public delegate void ByteMessageEventHandler(object sender, XConnectionEventArgs xe, ByteMessage msg);
	/// <summary>
	/// 远程命令消息事件代理
	/// </summary>
	/// <param name="sender">事件源</param>
	/// <param name="xe">事件参数</param>
	/// <param name="msg">远程命令消息</param>
	public delegate void CommandMessageEventHandler(object sender, XConnectionEventArgs xe, CommandMessage msg);
	/// <summary>
	/// XML消息事件代理
	/// </summary>
	/// <param name="sender">事件源</param>
	/// <param name="xe">事件参数</param>
	/// <param name="msg">XML消息</param>
	public delegate void XMLMessageEventHandler(object sender, XConnectionEventArgs xe, XMLMessage msg);
	/// <summary>
	/// 未识别消息事件代理
	/// </summary>
	/// <param name="sender">事件源</param>
	/// <param name="xe">事件参数</param>
	/// <param name="msg">未识别消息</param>
	public delegate void UnKownMessageEventHandler(object sender, XConnectionEventArgs xe, UnKownMessage msg);
    /// <summary>
    /// 注册事件代理
    /// </summary>
    /// <param name="sender">事件源</param>
    /// <param name="xe">事件参数</param>
    public delegate void RegisterEventHandler(object sender, XConnectionEventArgs xe,string[] args);
}
