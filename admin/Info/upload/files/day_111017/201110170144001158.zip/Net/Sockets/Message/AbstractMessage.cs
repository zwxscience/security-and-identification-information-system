﻿using System;
using System.Collections.Generic;

using System.Text;

namespace HuaBo.Net.Sockets.Message
{
	/// <summary>
	/// 消息编码枚举
	/// </summary>
	public enum MessageEncoding : byte
	{
		UTF8,
		ASCII,
		Default,
		Unicode,
		UnKown
	}
	/// <summary>
	/// AbstractMessage实现了IMessage接口是各种特定类型消息的基础类
	/// </summary>
	public class AbstractMessage : IMessage
	{
		protected object _value;
		protected byte[] _bytes;
		protected byte _type;
		/// <summary>
		/// message的值
		/// </summary>
		public object Value
		{
			get { return _value; }
		}
		/// <summary>
		/// message的类型
		/// </summary>
		public byte Type
		{
			get { return _type; }
		}
		/// <summary>
		/// message的字节形式
		/// </summary>
		public byte[] Bytes
		{
			get { return _bytes; }
		}
		/// <summary>
		/// 无参构造函数<see cref="AbstractMessage"/>
		/// </summary>
		public AbstractMessage()
		{

		}
	}
}
