﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HuaBo.Net.Sockets.Pipes
{
    public class PipeEventArgs
    {
        private IPipe _pipe;
        public IPipe Pipe { get { return _pipe; }}
        public PipeEventArgs(IPipe pipe)
        {
            _pipe = pipe;
        }
    }
}
