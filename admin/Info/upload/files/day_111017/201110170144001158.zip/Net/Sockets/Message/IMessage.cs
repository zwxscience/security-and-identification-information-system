﻿using System;
using System.Collections.Generic;

using System.Text;
	/// <summary>
	/// HuaBo.Net.Sockets.Message包含了一系列自定义消息
	/// </summary>
namespace HuaBo.Net.Sockets.Message
{
    /// <summary>
    /// IMessage接口
    /// </summary>
    public interface IMessage
    {
        /// <summary>
        /// message的字节形式
        /// </summary>
         byte[] Bytes{get;}
        /// <summary>
        /// message的类型
        /// </summary>
         byte Type{get;}
        /// <summary>
        /// message的值
        /// </summary>
         object Value{get;}
    }
}
