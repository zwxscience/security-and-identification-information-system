﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Net;
using System.Net.Sockets;

using HuaBo.Net.Sockets.Base;
using HuaBo.Net.Sockets.Message;
namespace HuaBo.Net.Sockets
{
	/// <summary>
	/// XClient是TCP/Client的实现
	/// </summary>
	public class XClient : XConnection
	{
		/// <summary>
		/// 异步连接回调
		/// </summary>
		private AsyncCallback connectCallBack;
		/// <summary>
		/// 根据XConnectionInformation创建XClient
		/// <see cref="XConnection"/> class.
		/// </summary>
		/// <param name="info">连接信息描述</param>
		public XClient(XConnectionInformation info) : base(info) { }
		/// <summary>
		/// 根据socket创建XClient
		/// 此构造函数用于将socket服务接受进来的socket包装为XClient
		/// </summary>
		/// <param name="socket">socket</param>
		/// <param name="sendBufferSize">发送缓冲区域大小</param>
		/// <param name="receiveBufferSize">接收缓冲区域大小</param>
		/// <param name="keepAlive">是否使用心跳包保持连接</param>
		/// <param name="keepAliveDelay">心跳包发送频率</param>
		public XClient(Socket socket, string name,int sendBufferSize, int receiveBufferSize, bool keepAlive, int keepAliveDelay) : base(socket, name,sendBufferSize, receiveBufferSize, keepAlive, keepAliveDelay) { }
		/// <summary>
		/// 根据socket创建XClient
		/// </summary>
		/// <param name="socket">socket</param>
		public XClient(Socket socket) : base(socket) { }
		/// <summary>
		/// 开始XSocket
		/// </summary>
		public override void Start()
		{
			if (_Socket == null)
			{
              
				_Socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
				_Socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                
			}
            try
            {
                _Socket.SendBufferSize = _Information.SendBufferSize;
                _Socket.ReceiveBufferSize = _Information.RecevieBufferSize;
            }
            catch (Exception) { }

			if (connectCallBack == null)
			{
				connectCallBack = new AsyncCallback(ConnectProcessing);
			}
			if (_Socket.Connected)
			{
				ReceiveDataProcessing(null);
			}else{
				ConnectProcessing(null);
			}
			base.Start();
		}

		/// <summary>
		/// 异步处理连接
		/// </summary>
		/// <param name="iar">异步操作对象</param>
		protected void ConnectProcessing(IAsyncResult iar)
		{
            try
            {
                if (iar == null)
                {
                    _Socket.BeginConnect(_Information.GetEndPoint(), connectCallBack, _Socket);
                }
                else
                {
                    _Socket.EndConnect(iar);
                    Send(new CommandMessage("register", _Information.Name));
                    ConnectEvent(new XConnectionEventArgs(this));
                    ReceiveDataProcessing(null);
                }
            }
            catch (ArgumentException)
            {
            }
            catch (SocketException xe)
            {
                //连接时主机未开启服务则会引发SocketException
                ErrorEvent(new XConnectionErrorEventArgs(this, xe));
            }
            catch (Exception)
            {
            }
        }

		/// <summary>
		/// 异步接收消息
		/// </summary>
		/// <param name="iar">异步操作对象</param>
		protected override void ReceiveDataProcessing(IAsyncResult iar)
		{
			base.ReceiveDataProcessing(iar);
			try
			{
				if (iar == null)
				{
					_Socket.BeginReceive(Data, 0, _Information.RecevieBufferSize, 0, ReceiveCallBack, _Socket);
				}
				else
				{
					int aliveBytes = _Socket.EndReceive(iar);
					if (aliveBytes != 0)
					{
						byte[] reciveData = new byte[aliveBytes];
						Array.Copy(Data, reciveData, aliveBytes);
						ReceiveEvent(new XConnectionReceiveEventArgs(this, reciveData));
						DispatchMessageEvent(reciveData);
						StopKeepAlive();
						StartKeepAlive();
					}
					else
					{
						LostEvent(new XConnectionEventArgs(this));
						ErrorEvent(new XConnectionErrorEventArgs(this, new SocketException(10053)));
						return;
					}
					_Socket.BeginReceive(Data, 0, _Information.RecevieBufferSize, 0, ReceiveCallBack, _Socket);
				}
			}
			catch (SocketException ex)
			{
				ErrorEvent(new XConnectionErrorEventArgs(this, ex));
			}
			catch (ObjectDisposedException oex)
			{
				//socket连接被关闭后会收到一个ObjectDisposedException
                _Socket = null;
                ErrorEvent(new XConnectionErrorEventArgs(this, oex));
              
			}
		}

	}
}
