﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Xml;
namespace HuaBo.Net.Sockets.Message
{
    /// <summary>
    /// XMLMessage表示xml消息
    /// 其结构为：消息类型(1byte)+消息编码(1byte)+消息长度(4byte)+消息内容
    /// </summary>
    public class XMLMessage : StringMessage
    {
		/// <summary>
		/// XML
		/// </summary>
        private XmlDocument _xml;
        /// <summary>
        /// 获取XML
        /// </summary>
        public XmlDocument XML
        {
            get { return _xml; }
        }
        /// <summary>
        /// 从二进制数据创建XML消息
        /// 此构造函数用于将socket接受到的数据转换为XML消息
        /// </summary>
        /// <param name="data">二进制数据</param>
        public XMLMessage(byte[] data)
        {
            _type = MessageType.XML;
            ParseByteToString(data);
            _xml = new XmlDocument();
            _xml.LoadXml(_message);
        }
        /// <summary>
        /// 从字符串创建XML消息
        /// </summary>
        /// <param name="msg">xml字符串描述</param>
        /// <param name="encode">编码</param>
        public XMLMessage(string msg, MessageEncoding encode)
        {
            _type = MessageType.XML;
            ParseStringToByte(msg, encode);
            _xml = new XmlDocument();
            _xml.LoadXml(_message);
        }
        /// <summary>
        /// 从XmlDocument创建XML消息
        /// </summary>
        /// <param name="xml">XmlDocument</param>
        /// <param name="encode">编码</param>
        public XMLMessage(XmlDocument xml, MessageEncoding encode)
        {
            _type = MessageType.XML;
            ParseStringToByte(xml.OuterXml, encode);
            _xml = new XmlDocument();
            _xml.LoadXml(_message);
        }
    }
}
