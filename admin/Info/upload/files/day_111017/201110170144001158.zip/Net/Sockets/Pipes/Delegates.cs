﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HuaBo.Net.Sockets.Pipes
{
    public delegate void PipeConnectedEventHander(object sender,PipeEventArgs args);
    public delegate void PipeDataEventHandler(object sender,PipeDataEventArgs args);
    public delegate void PipeLostEventHandler(object sender,PipeEventArgs args);
    public delegate void PipeErrorEventHandler(object sender,PipeErrorEventArgs args);
    public delegate void PipeRegisterAliasNameEventHandler(object sender,PipeRegsiterAliasNameEventArgs args);
}
