﻿using System;
using System.Collections.Generic;

using System.Text;

namespace HuaBo.Net.Sockets.Message
{
	/// <summary>
	/// MessageType定义了基础消息的类型
	/// </summary>
   public  class MessageType
    {
		/// <summary>
		/// 字节消息
		/// </summary>
       public const byte BYTE = 1;
	   /// <summary>
	   /// XML消息
	   /// </summary>
        public const byte XML =2;
		/// <summary>
		/// 文本消息
		/// </summary>
       public const byte STRING = 3;
	   /// <summary>
	   /// 远程命令消息
	   /// </summary>
       public const byte COMMAND = 4;
	   /// <summary>
	   /// 心跳包消息
	   /// </summary>
       public const byte ALIVE = 5;
	   /// <summary>
	   /// 未识别消息
	   /// </summary>
       public const byte UNKOWN = 10;
    }
}
