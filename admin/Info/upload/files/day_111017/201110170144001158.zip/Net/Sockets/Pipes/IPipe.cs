﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HuaBo.Net.Sockets.Pipes
{
   public interface IPipe :IDisposable
    {
       event PipeConnectedEventHander OnConnected;
       event PipeDataEventHandler OnData;
       event PipeErrorEventHandler OnError;
       event PipeLostEventHandler OnLost;
       event PipeRegisterAliasNameEventHandler OnRegAliasName;

       PipeInformation Information { get; }
       string AliasName { get; }
       string RemoteAlisaName { get; set; }
       int SendBufferSize { get; set; }
       int ReceiveBufferSize { get; set; }


    }
}
