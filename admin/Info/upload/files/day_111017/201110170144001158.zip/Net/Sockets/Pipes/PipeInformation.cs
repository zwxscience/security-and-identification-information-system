﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using HuaBo.Utils;

namespace HuaBo.Net.Sockets.Pipes
{
    public class PipeInformation
    {
        /// <summary>
        /// XConnectionType类型
        /// </summary>
        public PipeType Type;
        /// <summary>
        /// 发送数据缓冲区大小
        /// </summary>
        public int SendBufferSize;
        /// <summary>
        /// 接收数据缓冲区大小
        /// </summary>
        public int RecevieBufferSize;
        /// <summary>
        /// 是否使用心跳包保持连接
        /// </summary>
        public bool KeepAlive;
        /// <summary>
        /// 心跳包发送频率
        /// </summary>
        public int KeepAliveDelay;
        /// <summary>
        /// 要绑定或连接的网络端点
        /// </summary>
        public string IPAddress;
        /// <summary>
        /// 注册别名
        /// </summary>
        public string AliasName;
        /// <summary>
        /// 空的XConnectionInformation
        /// </summary>
        public static PipeInformation Empty
        {
            get { return new PipeInformation(); }
        }
        /// <summary>
        /// 是否为空
        /// </summary>
        public bool IsEmpty()
        {
            return this.IPAddress == null;
        }
        /// <summary>
        /// 创建一个XConnectionInformation
        /// </summary>
        /// <param name="type">类型</param>
        /// <param name="ipAddress">要绑定或要连接的网络端点.</param>
        /// <param name="sendBufferSize">发送缓冲区域大小</param>
        /// <param name="receiveBufferSize">接收缓存区域大小</param>
        /// <param name="keepAlive">是否使用心跳包保持连接</param>
        /// <param name="keepAliveDelay">心跳包发送频率</param>
        /// <returns>XConnectionInformation</returns>
        public static PipeInformation Create(PipeType type, string ipAddress, string name, int sendBufferSize, int receiveBufferSize, bool keepAlive, int keepAliveDelay)
        {
            PipeInformation info = new PipeInformation();
            info.Type = type;
            info.AliasName = name;
            info.IPAddress = ipAddress;
            info.SendBufferSize = sendBufferSize;
            info.RecevieBufferSize = receiveBufferSize;
            info.KeepAlive = keepAlive;
            info.KeepAliveDelay = keepAliveDelay;
            return info;
        }
        /// <summary>
        /// 创建一个XConnectionInformation
        /// 发送和接收缓冲区默认大小为8192字节
        /// </summary>
        /// <param name="type">类型</param>
        /// <param name="ipAddress">要绑定或要连接的网络端点.</param>
        /// <param name="keepAlive">是否使用心跳包保持连接</param>
        /// <param name="keepAliveDelay">心跳包发送频率</param>
        /// <returns>XConnectionInformation</returns>
        public static PipeInformation Create(PipeType type, string ipAddress, string name, bool keepAlive, int keepAliveDelay)
        {
            return Create(type, ipAddress, name, 8192, 8192, keepAlive, keepAliveDelay);
        }
        /// <summary>
        /// 创建一个XConnectionInformation
        /// 发送和接收缓冲区默认大小为8192字节，不使用心跳包保持连接
        /// </summary>
        /// <param name="type">类型</param>
        /// <param name="ipAddress">要绑定或要连接的网络端点</param>
        /// <returns>XConnectionInformation</returns>
        public static PipeInformation Create(PipeType type, string ipAddress, string name)
        {
            return Create(type, ipAddress, name, 8192, 8192, false, int.MaxValue);
        }
        /// <summary>
        /// 将字符串形式的网络端点转换为IPEndPoint
        /// </summary>
        public IPEndPoint GetEndPoint()
        {
            return StringConvert.ToIPEndPoint(IPAddress);
        }
    }
}
