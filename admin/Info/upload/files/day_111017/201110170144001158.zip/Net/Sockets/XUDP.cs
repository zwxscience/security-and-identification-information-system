﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Net;
using System.Net.Sockets;
using HuaBo.Net.Sockets.Base;
using HuaBo.Utils;
namespace HuaBo.Net.Sockets
{
	/// <summary>
	/// XUDP是UDP的实现
	/// </summary>
	public class XUDP : XConnection
	{
		/// <summary>
		/// 远程网络端口
		/// </summary>
		protected EndPoint _RemoteEndPoint;
		/// <summary>
		/// Initializes a new instance of the <see cref="XUDP"/> class.
		/// </summary>
		/// <param name="info">The info.</param>
		public XUDP(XConnectionInformation info)
			: base(info)
		{
			_Information.KeepAlive = false;
			_Information.KeepAliveDelay = int.MaxValue;

		}
		/// <summary>
		/// Initializes a new instance of the <see cref="XUDP"/> class.
		/// </summary>
		/// <param name="socket">The socket.</param>
		/// <param name="sendBufferSize">Size of the send buffer.</param>
		/// <param name="receiveBufferSize">Size of the receive buffer.</param>
		public XUDP(Socket socket, int sendBufferSize, int receiveBufferSize)
		{
			_Socket = _Socket;
			_Information = new XConnectionInformation();
			_Information.Type = XConnectionType.UDP;
			_Information.IPAddress = StringConvert.ToString((IPEndPoint)_Socket.LocalEndPoint);
			_Information.KeepAlive = false;
			_Information.KeepAliveDelay = int.MaxValue;
			_Information.SendBufferSize = sendBufferSize;
			_Information.RecevieBufferSize = receiveBufferSize;

			ReceiveCallBack = new AsyncCallback(ReceiveDataProcessing);
			Data = new byte[_Information.RecevieBufferSize];
		}
		/// <summary>
		/// 开始XSocket
		/// </summary>
		public override void Start()
		{
			_RemoteEndPoint = (EndPoint)new IPEndPoint(IPAddress.Any, 0);
			if (_Socket == null)
			{
				try
				{
					_Socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
					_Socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
					_Socket.Bind(Information.GetEndPoint());
				}
				catch (Exception ex)
				{
					ErrorEvent(new XConnectionErrorEventArgs(this, ex));
				}
			}
			_Socket.SendBufferSize = _Information.SendBufferSize;
			_Socket.ReceiveBufferSize = _Information.RecevieBufferSize;
			ReceiveDataProcessing(null);
		}
		/// <summary>
		/// 获取远程网络端点
		/// </summary>
		/// <value>EndPoint</value>
		public override EndPoint RemoteEndPoint
		{
			get
			{
				return _RemoteEndPoint;
			}
		}
		/// <summary>
		/// 发送数据
		/// </summary>
		/// <param name="data">二进制数据</param>
		public override void Send(byte[] data)
		{
			try
			{
				_Socket.SendTo(data, (IPEndPoint)_RemoteEndPoint);
			}
			catch (SocketException ex)
			{
				LostEvent(new XConnectionEventArgs(this));
				ErrorEvent(new XConnectionErrorEventArgs(this, ex));
			}
		}
		/// <summary>
		/// 异步接收消息
		/// </summary>
		/// <param name="iar">异步操作对象</param>
		protected override void ReceiveDataProcessing(IAsyncResult iar)
		{
			base.ReceiveDataProcessing(iar);
			try
			{
				if (iar == null)
				{
					_Socket.BeginReceiveFrom(Data, 0, Data.Length, 0, ref _RemoteEndPoint, ReceiveCallBack, null);
				}
				else
				{
					int aliveBytes = _Socket.EndReceiveFrom(iar, ref _RemoteEndPoint);
					if (aliveBytes != 0)
					{
						byte[] receiveBytes = new byte[aliveBytes];
						Array.Copy(Data, receiveBytes, aliveBytes);
						ReceiveEvent(new XConnectionReceiveEventArgs(this, receiveBytes));
						DispatchMessageEvent(receiveBytes);
					}
					else
					{
						LostEvent(new XConnectionEventArgs(this));
						ErrorEvent(new XConnectionErrorEventArgs(this, new SocketException(10053)));
						
					}
					_Socket.BeginReceiveFrom(Data, 0, Data.Length, 0, ref _RemoteEndPoint, ReceiveCallBack, null);
				}
			}
			catch (SocketException ex)
			{
				LostEvent(new XConnectionEventArgs(this));
				ErrorEvent(new XConnectionErrorEventArgs(this, ex));
				_Socket.BeginReceiveFrom(Data, 0, Data.Length, 0, ref _RemoteEndPoint, ReceiveCallBack, null);
			}
			catch (ObjectDisposedException)
			{
				//socket连接被关闭后会收到一个ObjectDisposedException
			}
		}
	}
}
