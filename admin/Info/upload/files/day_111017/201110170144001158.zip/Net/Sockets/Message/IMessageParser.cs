﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HuaBo.Net.Sockets.Message
{
    /// <summary>
    ///IMessageParser接口定义了消息解析器的基础行为
    /// </summary>
    public interface IMessageParser
    {
        /// <summary>
        /// 将2进制数据解析为特定类型消息
        /// </summary>
        ///<param name="data">二进制数据</param>
        IMessage Parse(byte[] data);
    }
}
