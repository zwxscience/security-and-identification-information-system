﻿using System;
using System.Collections.Generic;

using System.Text;

namespace HuaBo.Net.Sockets.Message
{
	/// <summary>
	/// AliveMessage表示心跳包消息
	/// 其结构为：消息类型(1byte)+消息长度(1byte)+固定消息内容
	/// </summary>
    public class AliveMessage : AbstractMessage
    {
		/// <summary>
		/// 心跳包字符
		/// </summary>
        private const string aliveStr = "*p*";


		/// <summary>
		///无参构造函数<see cref="AliveMessage"/>
		/// </summary>
        public AliveMessage()
        {
            _type = MessageType.ALIVE;
            _value = aliveStr;
            byte[] aliveByte = Encoding.UTF8.GetBytes(aliveStr);
            _bytes = new byte[1 + 1 + aliveByte.Length];
            _bytes[0] = MessageType.ALIVE;
            _bytes[1] = (byte)aliveByte.Length;
            Array.Copy(aliveByte, 0, _bytes, 2, aliveByte.Length);
        }
    }
}
