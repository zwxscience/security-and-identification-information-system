﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Net;
using System.Net.Sockets;

using HuaBo.Utils;
using HuaBo.Net.Sockets.Base;

namespace HuaBo.Net.Sockets
{
    /// <summary>
    /// XServer是TCP/Server的实现
    /// </summary>
    public class XServer : XConnection
    {
        /// <summary>
        /// 异步接收连接回调
        /// </summary>
        private AsyncCallback AcceptCallBack;
        /// <summary>
        /// 客户端列表
        /// </summary>
        protected Dictionary<ClientKey, XClient> Clients;
        /// <summary>
        /// 根据XConnectionInformation创建XServer 
        /// <see cref="XConnection"/> class.
        /// </summary>
        /// <param name="info">连接信息描述</param>
        public XServer(XConnectionInformation info) : base(info) { }
        /// <summary>
        /// 根据socket创建XServer
        /// <p>此构造函数用于将已有socket连接包装为XServer</p>
        /// </summary>
        /// <param name="socket">socket</param>
        /// <param name="type">XConnection类型</param>
        /// <param name="sendBufferSize">发送缓冲区域大小</param>
        /// <param name="receiveBufferSize">接收缓冲区域大小</param>
        /// <param name="keepAlive">是否使用心跳包保持连接</param>
        /// <param name="keepAliveDelay">心跳包发送频率</param>
        /// <param name="ipAddress">要绑定或者连接的网络端点</param>
        public XServer(Socket socket, string name,XConnectionType type, int sendBufferSize, int receiveBufferSize, bool keepAlive, int keepAliveDelay, string ipAddress) : base(socket,name, type, sendBufferSize, receiveBufferSize, keepAlive, keepAliveDelay, ipAddress) { }
        /// <summary>
        /// 开始XSocket
        /// </summary>
        public override void Start()
        {
            if (_Socket == null)
            {
                try
                {
                    _Socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    _Socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                    _Socket.Bind(_Information.GetEndPoint());
                    _Socket.Listen(255);
                }
                catch (Exception ex)
                {
                    ErrorEvent(new XConnectionErrorEventArgs(this, ex));
                }
            }
            if (AcceptCallBack == null)
            {
                AcceptCallBack = new AsyncCallback(AcceptProcessing);
            }
            if (Clients == null)
            {
                Clients = new Dictionary<ClientKey, XClient>();
            }
            AcceptProcessing(null);
        }
        /// <summary>
        /// 停止XSocket
        /// </summary>
        public override void Stop()
        {
            StopKeepAlive();
            if (Clients != null)
            {
                lock (Clients)
                {
                    foreach (XClient client in Clients.Values)
                    {
                        client.OnLost -= new XConntionLostEventHandler(client_OnLost);
                        client.OnData -= new XConnectionReceiveEventHandler(client_OnData);
                        client.OnError -= new XConnectionErrorEventHandler(client_OnError);
                        client.OnXMLMessage -= new XMLMessageEventHandler(client_OnXMLMessage);
                        client.OnByteMessage -= new ByteMessageEventHandler(client_OnByteMessage);
                        client.OnAliveMessage -= new AliveMessageEventHandler(client_OnAliveMessage);
                        client.OnStringMessage -= new StringMessageEventHandler(client_OnStringMessage);
                        client.OnUnKownMessage -= new UnKownMessageEventHandler(client_OnUnKownMessage);
                        client.OnCommandMessage -= new CommandMessageEventHandler(client_OnCommandMessage);
                        client.Dispose();
                    }
                }
                Clients.Clear();
            }
            base.Stop();
        }
        /// <summary>
        /// 发送数据
        /// </summary>
        /// <param name="data">二进制数据</param>
        public override void Send(byte[] data)
        {

            if (Clients != null)
            {
                lock (Clients)
                {
                    foreach (XClient client in Clients.Values)
                    {
                        client.Send(data);
                    }
                }
            }
        }
        /// <summary>
        /// 发送数据到某一网络端点
        /// </summary>
        /// <param name="data">二进制数据</param>
        /// <param name="endPoint">网络端点</param>
        public override void Send(byte[] data, IPEndPoint endPoint)
        {
            Send(data, StringConvert.ToString(endPoint));
        }
        /// <summary>
        /// 根据ip或者别名发送数据
        /// </summary>
        /// <param name="data">数据</param>
        /// <param name="ipOrName">ip或者别名</param>
        public override void Send(byte[] data, string ipOrName)
        {
            if (Clients != null)
            {
                lock (Clients)
                {
                    foreach (ClientKey key in Clients.Keys)
                    {
                      
                        if (key == ipOrName)
                        {
                      
                            Clients[key].Send(data);
                            return;
                        }
                    }
                }
            }
        }
        /// <summary>
        /// 发送数据
        /// </summary>
        /// <param name="msg">IMessage类型消息</param>
        public override void Send(Message.IMessage msg)
        {
            Send(msg.Bytes);
        }
        /// <summary>
        /// 发送数据到某一网络端点
        /// </summary>
        /// <param name="msg">IMessage类型消息</param>
        /// <param name="endPoint">网络端点</param>
        public override void Send(Message.IMessage msg, IPEndPoint endPoint)
        {
            Send(msg.Bytes, StringConvert.ToString(endPoint));
        }
        /// <summary>
        /// 根据ip或者别名发送信息
        /// </summary>
        /// <param name="msg">信息</param>
        /// <param name="ipOrName">ip或者别名</param>
        public void Send(Message.IMessage msg, string ipOrName)
        {
            Send(msg.Bytes, ipOrName);
        }
        /// <summary>
        /// 销毁
        /// </summary>
        public override void Dispose()
        {
            Stop();
            base.Dispose();
        }

        /// <summary>
        /// 异步接收连接
        /// </summary>
        /// <param name="iar">异步操作对象</param>
        protected void AcceptProcessing(IAsyncResult iar)
        {
            if (_Socket == null) return;
            try
            {
                if (iar == null)
                {
                    _Socket.BeginAccept(AcceptCallBack, _Socket);
                }
                else
                {
                    Socket socket = _Socket.EndAccept(iar);
                    XClient client = new XClient(socket,_Information.Name, _Information.SendBufferSize, _Information.RecevieBufferSize, _Information.KeepAlive, _Information.KeepAliveDelay);
                    lock (Clients)
                    {
                        Clients.Add(new ClientKey(StringConvert.ToString((IPEndPoint)socket.RemoteEndPoint)), client);
                    }
                    //将接收到的连接转换为XClient
                    client.MessageParser = _MessageParser;
                    client.OnLost += new XConntionLostEventHandler(client_OnLost);
                    client.OnData += new XConnectionReceiveEventHandler(client_OnData);
                    client.OnError += new XConnectionErrorEventHandler(client_OnError);
                    client.OnXMLMessage += new XMLMessageEventHandler(client_OnXMLMessage);
                    client.OnByteMessage += new ByteMessageEventHandler(client_OnByteMessage);
                    client.OnAliveMessage += new AliveMessageEventHandler(client_OnAliveMessage);
                    client.OnStringMessage += new StringMessageEventHandler(client_OnStringMessage);
                    client.OnUnKownMessage += new UnKownMessageEventHandler(client_OnUnKownMessage);
                    client.OnCommandMessage += new CommandMessageEventHandler(client_OnCommandMessage);
                    client.OnRegister += new RegisterEventHandler(client_OnRegister);
                    client.Start();
                    ConnectEvent(new XConnectionEventArgs(client));
                    _Socket.BeginAccept(AcceptCallBack, _Socket);
                }
            }
            catch (ArgumentException)
            {
                //由Stop方法停止后再Start,EndAccpet会产生一个来自另一个回调的ArgumentException
            }
        }

        void client_OnRegister(object sender, XConnectionEventArgs xe,string[] args)
        {
            string ip = StringConvert.ToString((IPEndPoint)xe.Connection.RemoteEndPoint);
         
            UpdateClientAliasName(ip, xe.Connection.RemoteName);
          
            RegisterEvent(xe,args);
        }
        /// <summary>
        /// 移除一个客户端连接
        /// </summary>
        /// <param name="client">客户端连接</param>
        protected void RmoveClient(XClient client)
        {
            client.OnLost -= new XConntionLostEventHandler(client_OnLost);
            client.OnData -= new XConnectionReceiveEventHandler(client_OnData);
            client.OnError -= new XConnectionErrorEventHandler(client_OnError);
            client.OnXMLMessage -= new XMLMessageEventHandler(client_OnXMLMessage);
            client.OnByteMessage -= new ByteMessageEventHandler(client_OnByteMessage);
            client.OnAliveMessage -= new AliveMessageEventHandler(client_OnAliveMessage);
            client.OnStringMessage -= new StringMessageEventHandler(client_OnStringMessage);
            client.OnUnKownMessage -= new UnKownMessageEventHandler(client_OnUnKownMessage);
            client.OnCommandMessage -= new CommandMessageEventHandler(client_OnCommandMessage);
            client.OnRegister -= new RegisterEventHandler(client_OnRegister);

            string ipOrName = client.RemoteName;
            if (client.RemoteEndPoint != null)
                ipOrName = ((IPEndPoint)client.RemoteEndPoint).ToString();
            
            if (Clients != null)
            {
                lock (Clients)
                {
                    foreach (ClientKey key in Clients.Keys)
                    {
                        if (key == ipOrName)
                        {
                            Clients.Remove(key);
                            return;
                        }
                    }
                }
            }
            Console.WriteLine("删除客户端:" + client.RemoteName);
            client.Dispose();
        }

        protected void UpdateClientAliasName(string ip, string aliasName)
        {
            if (Clients != null)
            {
                lock (Clients)
                {
                    foreach (ClientKey key in Clients.Keys)
                    {
                       
                        if (key == ip)
                        {
                          
                            key.AliasName = aliasName;
                            return;
                        }
                    }
                }
            }
        }
        /// <summary>
        /// Client_s the on command message.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="xe">The <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/> instance containing the event data.</param>
        /// <param name="msg">The MSG.</param>
        void client_OnCommandMessage(object sender, XConnectionEventArgs xe, Message.CommandMessage msg)
        {
            CommandMessageEvent(xe, msg);
        }

        /// <summary>
        /// Client_s the on un kown message.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="xe">The <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/> instance containing the event data.</param>
        /// <param name="msg">The MSG.</param>
        void client_OnUnKownMessage(object sender, XConnectionEventArgs xe, Message.UnKownMessage msg)
        {
            UnKownMessageEvent(xe, msg);
        }

        /// <summary>
        /// Client_s the on string message.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="xe">The <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/> instance containing the event data.</param>
        /// <param name="msg">The MSG.</param>
        void client_OnStringMessage(object sender, XConnectionEventArgs xe, Message.StringMessage msg)
        {

            StringMessageEvent(xe, msg);
        }

        /// <summary>
        /// Client_s the on alive message.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="xe">The <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/> instance containing the event data.</param>
        /// <param name="msg">The MSG.</param>
        void client_OnAliveMessage(object sender, XConnectionEventArgs xe, Message.AliveMessage msg)
        {
            AliveMessageEvent(xe, msg);
        }

        /// <summary>
        /// Client_s the on byte message.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="xe">The <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/> instance containing the event data.</param>
        /// <param name="msg">The MSG.</param>
        void client_OnByteMessage(object sender, XConnectionEventArgs xe, Message.ByteMessage msg)
        {
            ByteMessageEvent(xe, msg);
        }

        /// <summary>
        /// Client_s the on XML message.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="xe">The <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/> instance containing the event data.</param>
        /// <param name="msg">The MSG.</param>
        void client_OnXMLMessage(object sender, XConnectionEventArgs xe, Message.XMLMessage msg)
        {
            XMLMessageEvent(xe, msg);
        }

        /// <summary>
        /// Handles the OnError event of the client control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="xe">The <see cref="HuaBo.Net.Sockets.Base.XConnectionErrorEventArgs"/> instance containing the event data.</param>
        void client_OnError(object sender, XConnectionErrorEventArgs xe)
        {
            ErrorEvent(xe);
            RmoveClient(sender as XClient);
        }

        /// <summary>
        /// Handles the OnData event of the client control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="xe">The <see cref="HuaBo.Net.Sockets.Base.XConnectionReceiveEventArgs"/> instance containing the event data.</param>
        void client_OnData(object sender, XConnectionReceiveEventArgs xe)
        {
            ReceiveEvent(xe);
        }

        /// <summary>
        /// Handles the OnLost event of the client control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="xe">The <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/> instance containing the event data.</param>
        void client_OnLost(object sender, XConnectionEventArgs xe)
        {
            LostEvent(xe);
        }
    }
    /// <summary>
    /// TCP/Server客户端集合键
    /// </summary>
    public class ClientKey
    {
        /// <summary>
        /// ip地址
        /// </summary>
        public string IpAddress;
        /// <summary>
        /// 别名
        /// </summary>
        public string AliasName;
        /// <summary>
        /// Initializes a new instance of the <see cref="ClientKey"/> class.
        /// </summary>
        public ClientKey()
        {
            IpAddress = "";
            AliasName = "";
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="ClientKey"/> class.
        /// </summary>
        /// <param name="ip">The ip.</param>
        public ClientKey(string ip)
        {
            IpAddress = ip;
            AliasName = "";
        }
        /// <summary>
        /// Implements the operator ==.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="ipOrName">Name of the ip or.</param>
        /// <returns>The result of the operator.</returns>
        public static bool operator ==(ClientKey key, string ipOrName)
        {
            ipOrName = ipOrName.ToLower();
            return (key.IpAddress == ipOrName || key.AliasName.ToLower() == ipOrName.ToLower());
        }
        /// <summary>
        /// Implements the operator !=.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="ipOrName">Name of the ip or.</param>
        /// <returns>The result of the operator.</returns>
        public static bool operator !=(ClientKey key, string ipOrName)
        {
            ipOrName = ipOrName.ToLower();
            return (key.IpAddress != ipOrName && key.AliasName.ToLower() != ipOrName.ToLower());
        }
    }
}
