﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HuaBo.Net.Sockets.Pipes
{
    public class PipeRegsiterAliasNameEventArgs : PipeEventArgs
    {
        private string _aliasName;
        public string AliasName { get {return _aliasName;}}
        public PipeRegsiterAliasNameEventArgs(IPipe pipe, string aliasName)
            : base(pipe)
        {
            _aliasName = aliasName;
        }
    }
}
