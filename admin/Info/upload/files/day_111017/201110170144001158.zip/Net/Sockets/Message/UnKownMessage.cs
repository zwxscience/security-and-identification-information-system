﻿using System;
using System.Collections.Generic;

using System.Text;

namespace HuaBo.Net.Sockets.Message
{
    /// <summary>
    /// UnKownMessage表示未能识别类型的消息
    /// </summary>
    public class UnKownMessage:AbstractMessage
    {
        /// <summary>
        /// 从2进制创建消息
        /// </summary>
        ///<param name="data">二进制数据</param>
        public UnKownMessage(byte[] data){
            _type = MessageType.UNKOWN;
            _value = data;
            _bytes = data;
        }
    }
}
