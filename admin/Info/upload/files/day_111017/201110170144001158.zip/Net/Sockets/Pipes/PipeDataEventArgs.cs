﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HuaBo.Net.Sockets.Pipes
{
    public class PipeDataEventArgs:PipeEventArgs
    {
        private byte[] _data;
        public byte[] Data { get { return _data; } }
        public  PipeDataEventArgs(IPipe pipe,byte[] data):base(pipe){
            _data = data;
        }
    }
}
