﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace HuaBo.Net.FileTransport
{
    /// <summary>
    /// TransportInfo表示单一文件传输任务(可序列化)
    /// </summary>
    [Serializable]
    public class TransportInfo
    {
        /// <summary>
        /// 文件远程目录
        /// </summary>
        [XmlAttribute]
        public string RemoteFile;
        /// <summary>
        /// 文件总字节数
        /// </summary>
        [XmlAttribute]
        public long TotalBytes;
        /// <summary>
        /// 文件字节片段大小
        /// </summary>
        [XmlAttribute]
        public int BlockSize;
        /// <summary>
        /// 文件传输目标路径
        /// </summary>
        [XmlAttribute]
        public string TargetFile;
        /// <summary>
        /// 是否已传输完成
        /// </summary>
        [XmlAttribute]
        public bool Finished;

        /// <summary>
        /// 构造函数
        /// <see cref="TransportInfo"/>
        /// </summary>
        public TransportInfo()
        {
        }
        /// <summary>
        /// 构造函数<see cref="TransportInfo"/>
        /// </summary>
        /// <param name="remoteFile">文件远程目录</param>
        /// <param name="totalBytes">文件字节片段大小</param>
        /// <param name="blockSize">文件字节片段大小</param>
        /// <param name="targetFile">文件传输目标路径</param>
        public TransportInfo(string remoteFile, long totalBytes, int blockSize, string targetFile)
        {
            RemoteFile = remoteFile;
            TotalBytes = totalBytes;
            TargetFile = targetFile;
            BlockSize = blockSize;
            Finished = false;
        }
    }
}
