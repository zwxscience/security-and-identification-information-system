﻿using System;
using System.Collections.Generic;
using System.Text;

using HuaBo.Net.Sockets.Base;
using HuaBo.Net.Sockets.Message;

namespace HuaBo.Net.FileTransport
{
    /// <summary>
    /// FileTransmission是文件传输过程的具体实现
    /// </summary>
    public class FileTransmission : IDisposable
    {
        #region 成员变量


        /// <summary>
        /// connection
        /// </summary>
        private IXConnection connection;
        private long lastFinishedBytes;
        /// <summary>
        /// 传输开始时间
        /// </summary>
        private DateTime _startTime;
        /// <summary>
        /// 上一个片段传输用时
        /// </summary>
        private DateTime _pervBlockTime;
        /// <summary>
        /// 
        /// </summary>
        private double _byteSpeed;
        /// <summary>
        /// 
        /// </summary>
        private int _currentBlockIndex;
        /// <summary>
        /// 
        /// </summary>
        private NetFile netFile;

        private bool _runing = false;

        public bool Runing { get { return _runing; } }
        #endregion

        #region get/set
        /// <summary>
        /// Gets the connection.
        /// </summary>
        public IXConnection Connection { get { return connection; } }
        /// <summary>
        /// 获取NetFile
        /// </summary>
        /// <value>
        /// 要传输的文件
        /// </value>
        public NetFile NetFile { get { return netFile; } set { if (!_runing) { netFile = value; lastFinishedBytes = netFile.TransprotedBytes; } } }
        /// <summary>
        /// 获取传输启动时间
        /// </summary>
        public DateTime StartTime { get { return _startTime; } }
        /// <summary>
        /// 获取传输已用时
        /// </summary>
        public double TimePast { get { return (DateTime.Now - _startTime).TotalSeconds; } }
        /// <summary>
        /// 估计剩余时间
        /// </summary>
        public double TimeRemaining { get { int blockRemaining = netFile.TotalBlock - netFile.FinishedBlock; if ((int)BlockAverSpeed == 0)return 0; return TimeSpan.FromSeconds(blockRemaining / BlockAverSpeed).TotalSeconds; } }
        /// <summary>
        /// 获取平均每秒传输块数
        /// </summary>
        public double BlockAverSpeed { get { return (netFile.FinishedBlock-(int)(lastFinishedBytes/netFile.BlockSize)) / TimePast; } }
        /// <summary>
        /// 获取每秒平均传输字节数/byte
        /// </summary>
        public double ByteAverSpeed { get { return (netFile.TransprotedBytes-lastFinishedBytes) / TimePast; } }
        /// <summary>
        /// 获取每秒平均传输字节数/kb
        /// </summary>
        public double KByteAverSpeed { get { return ByteAverSpeed / 1024; } }
        /// <summary>
        /// 获取瞬间速度
        /// </summary>
        public double ByteSpeed { get { return _byteSpeed; } }
        /// <summary>
        /// Gets the K byte speed.
        /// </summary>
        public double KByteSpeed { get { return _byteSpeed / 1024; } }
        /// <summary>
        /// 获取文件总字节数
        /// </summary>
        public long TotalBytes { get { return netFile.TotalBytes; } }
        /// <summary>
        /// 获取已完成的字节数
        /// </summary>
        public long FinishedBytes { get { return netFile.TransprotedBytes; } }
        /// <summary>
        /// 获取进度百分比
        /// </summary>
        public double Progress { get { return ((double)FinishedBytes / (double)TotalBytes) * 100; } }
        #endregion

        #region 事件
        /// <summary>
        /// Occurs when [on block finished].
        /// </summary>
        public event BlockFinishedEventHandler OnBlockFinished;
        /// <summary>
        /// Occurs when [on finished].
        /// </summary>
        public event FinishedEventHandler OnFinished;
        /// <summary>
        /// Occurs when [on error].
        /// </summary>
        public event FileTransmissionErrorHandler OnError;
        #endregion

        #region 构造函数
        /// <summary>
        /// 通过一个IXConnection 创建文件传输
        /// <see cref="FileTransmission"/>
        /// </summary>
        /// <param name="connection">IXConnection实例</param>
        public FileTransmission(IXConnection connection)
        {
            this.connection = connection;
            this.connection.OnByteMessage += new ByteMessageEventHandler(connection_OnByteMessage);
            this.connection.OnCommandMessage += new CommandMessageEventHandler(connection_OnCommandMessage);
            this.connection.OnMessageError += new MessageParseErrorEventHandler(connection_OnMessageError);
            this.connection.OnUnKownMessage += new UnKownMessageEventHandler(connection_OnUnKownMessage);
            this.connection.OnError+=new XConnectionErrorEventHandler(connection_OnError);
            this.connection.OnAliveMessage += new AliveMessageEventHandler(connection_OnAliveMessage);
        }

        void connection_OnAliveMessage(object sender, XConnectionEventArgs xe, AliveMessage msg)
        {
           
        }

        void connection_OnUnKownMessage(object sender, XConnectionEventArgs xe, UnKownMessage msg)
        {
            Console.WriteLine("接收到未能识别的消息！！！");
        }
        /// <summary>
        /// 通过一个IXConnection创建文件传输指定NetFile
        /// <see cref="FileTransmission"/>
        /// </summary>
        /// <param name="connection">IXConnection实例</param>
        /// <param name="file">要传输的NetFile文件</param>
        public FileTransmission(IXConnection connection, NetFile file)
            : this(connection)
        {
            netFile = file;
            lastFinishedBytes = netFile.TransprotedBytes;

        }
        #endregion

        #region 实现
        /// <summary>
        /// 接收消息发生错误
        /// </summary>
        /// <param name="sender">事件源</param>
        /// <param name="ex">异常信息</param>
        void connection_OnMessageError(object sender, Sockets.Message.MessageParseException ex)
        {
            if (ex.Type == MessageType.BYTE)
            {
                Console.WriteLine("消息解析出错，重新请求{0}块！" , netFile.FinishedBlock);
                RequestBlock(netFile.FinishedBlock,true);
            }
        }

        /// <summary>
        /// 接受到远程命令
        /// </summary>
        /// <param name="sender">事件源</param>
        /// <param name="xe">
        /// 事件参数
        /// <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/>
        /// </param>
        /// <param name="msg">远程命令</param>
        void connection_OnCommandMessage(object sender, XConnectionEventArgs xe, Sockets.Message.CommandMessage msg)
        {

            int id = -1;
            double offset = -1d;
            switch (msg.Option)
            {
                case TransportOption.GET_BLOCK:
                    id = Convert.ToInt32(msg.Arguments[0]);
                     offset= (DateTime.Now - _pervBlockTime).TotalSeconds;
                     Console.WriteLine(id + "%%%%%%%%%%%%%%%%%%%%%%%%%%" + netFile.TotalBlock);
                if (id == netFile.TotalBlock - 1)
                {
                    _byteSpeed =(double)netFile.LastBlockSize / offset;
                    _byteSpeed = double.IsPositiveInfinity(_byteSpeed) ? netFile.LastBlockSize : _byteSpeed;
                }
                else
                {
                    _byteSpeed = (double)netFile.BlockSize / offset;
                    _byteSpeed = double.IsPositiveInfinity(_byteSpeed) ? netFile.BlockSize : _byteSpeed;
                }
               
                _pervBlockTime = DateTime.Now;
                    ByteMessage block = netFile.Read(Convert.ToInt32(msg.Arguments[0]));
                    connection.Send(block);
                    break;
                case TransportOption.RE_GET_BLOCK:

                    id=Convert.ToInt32(msg.Arguments[0]);
                    offset= (DateTime.Now - _pervBlockTime).TotalSeconds;
                
                if (id == netFile.TotalBlock - 1)
                {
                    _byteSpeed =(double)netFile.LastBlockSize / offset;
                    _byteSpeed = double.IsPositiveInfinity(_byteSpeed) ? netFile.LastBlockSize : _byteSpeed;
                }
                else
                {
                    _byteSpeed = (double)netFile.BlockSize / offset;
                    _byteSpeed = double.IsPositiveInfinity(_byteSpeed) ? netFile.BlockSize : _byteSpeed;
                }
               
                _pervBlockTime = DateTime.Now;
                    Console.WriteLine("文件{0},请求重新传输字节片段(id:{1})",NetFile.RemoteFile,id);
                    netFile.TransprotedBytes-=(id==netFile.TotalBlock-1?netFile.LastBlockSize:netFile.BlockSize);
                    ByteMessage bk = netFile.Read(id);
                    Console.WriteLine("{0}^^^^^{1}", bk.Length, bk.Index);
                    connection.Send(netFile.Read(id));
                    break;
                case TransportOption.FINISH:
                    if (OnFinished != null)
                    {
                        OnFinished(this);
                    }
                    break;
            }
        }
        /// <summary>
        /// 接收到字节片段
        /// </summary>
        /// <param name="sender">事件源</param>
        /// <param name="xe">
        /// 事件参数
        /// <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/>
        /// </param>
        /// <param name="msg">字节片段</param>
        void connection_OnByteMessage(object sender, XConnectionEventArgs xe, Sockets.Message.ByteMessage msg)
        {
            Console.WriteLine(netFile.TransprotedBytes + "*******" + netFile.TotalBytes + "***********" + netFile.FinishedBytes);
            Console.WriteLine(msg.Length + "/////" + msg.Index + "/////" + netFile.BlockSize + "????" + netFile.LastBlockSize + "////" + netFile.TotalBlock);
            if (msg.Length == netFile.BlockSize || msg.Length == netFile.LastBlockSize)
            {
                netFile.Write(msg);
                double offset= (DateTime.Now - _pervBlockTime).TotalSeconds;
                
                if (msg.Index == netFile.TotalBlock - 1)
                {
                    _byteSpeed =(double)netFile.LastBlockSize / offset;
                    _byteSpeed = double.IsPositiveInfinity(_byteSpeed) ? netFile.LastBlockSize : _byteSpeed;
                }
                else
                {
                    _byteSpeed = (double)netFile.BlockSize / offset;
                    _byteSpeed = double.IsPositiveInfinity(_byteSpeed) ? netFile.BlockSize : _byteSpeed;
                }
               
                _pervBlockTime = DateTime.Now;
                if (OnBlockFinished != null)
                {
                    OnBlockFinished(this, new BlockFinishedEventArgs(msg.Index));
                }
                Console.WriteLine(netFile.TotalBytes + "%%%%%%%%%%%" + netFile.TransprotedBytes + "???????" + netFile.Finished);
                if (netFile.Finished)
                {
                    if (OnFinished != null)
                    {
                        connection.Send(new CommandMessage(TransportOption.FINISH));
                        OnFinished(this);
                        
                    }
                    
                }     
                else
                {
                    RequestBlock(msg.Index + 1,false);
                }
            }
            else
            {
                Console.WriteLine("传输文件{3}字节块(id:{0})长度不正确！(需要长度{1},实际长度{2})", msg.Index, msg.Index == NetFile.TotalBlock-1 ? netFile.LastBlockSize : netFile.BlockSize, msg.Length,netFile.RemoteFile);
                RequestBlock(msg.Index,true);
            }
        }

        /// <summary>
        /// 连接发生异常
        /// </summary>
        /// <param name="sender">事件源</param>
        /// <param name="xe">事件参数<see cref="HuaBo.Net.Sockets.Base.XConnectionErrorEventArgs"/> 
        /// </param>
        void connection_OnError(object sender, XConnectionErrorEventArgs xe)
        {
            Console.WriteLine("传输出错！"+xe.Exception.ToString());
            _runing = false;
            if (OnError != null)
            {
                OnError(this, new FileTransmissionErrorEventArgs(xe.Exception));
            }
        }

      
        /// <summary>
        /// 请求字节片段
        /// </summary>
        /// <param name="index">字节片段id</param>
        private void RequestBlock(int index,bool reget)
        {
            _currentBlockIndex = index;
            connection.Send(new CommandMessage(reget?TransportOption.RE_GET_BLOCK:TransportOption.GET_BLOCK, index));
        }
        /// <summary>
        /// 准备接收数据
        /// </summary>
        public void Receive()
        {
            _runing = true;
            _startTime = DateTime.Now;
            _pervBlockTime = DateTime.Now;
            Console.WriteLine("{1}>>开始接受文件！{0}", netFile.RemoteFile,DateTime.Now.ToLongTimeString());
            new System.Threading.Thread(new System.Threading.ThreadStart(delegate { System.Threading.Thread.Sleep(3000); connection.Send(new CommandMessage(TransportOption.GET_FILE, netFile.RemoteFile, netFile.FinishedBytes)); })).Start();
            
        }

        /// <summary>
        /// 开始接受数据
        /// </summary>
        public void Start()
        {
            _runing = true;
            _startTime = DateTime.Now;
            _pervBlockTime = DateTime.Now;
            connection.Send(new CommandMessage(TransportOption.GET_BLOCK, netFile.FinishedBlock));
        }

        /// <summary>
        /// 准备发送数据
        /// </summary>
        public void Send()
        {
            _startTime = DateTime.Now;
            _pervBlockTime = DateTime.Now;
            _runing = true;
            connection.Send(new CommandMessage(TransportOption.READY));
        }
        /// <summary>
        /// 停止接收数据
        /// </summary>
        public void Stop()
        {
            _runing = false;
            if(netFile!=null)
            netFile.Dispose();
        }

        /// <summary>
        /// 执行与释放或重置非托管资源相关的应用程序定义的任务。
        /// </summary>
        public void Dispose()
        {
            this.connection.OnByteMessage -= new ByteMessageEventHandler(connection_OnByteMessage);
            this.connection.OnCommandMessage -= new CommandMessageEventHandler(connection_OnCommandMessage);
            this.connection.OnMessageError -= new MessageParseErrorEventHandler(connection_OnMessageError);
            this.connection.OnError -= new XConnectionErrorEventHandler(connection_OnError);
            this.connection.OnUnKownMessage -= new UnKownMessageEventHandler(connection_OnUnKownMessage);
            this.connection.OnAliveMessage -= new AliveMessageEventHandler(connection_OnAliveMessage);
            connection = null;
            Stop();
            netFile = null;
        }
        #endregion
    }
}
