﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using HuaBo.Net.Sockets;
using HuaBo.Net.Sockets.Base;
using HuaBo.Net.Sockets.Message;


namespace HuaBo.Net.FileTransport
{
    /// <summary>
    /// TransportSender是文件传输发送端的具体实现
    /// </summary>
    public class TransportSender : XServer
    {
        #region 成员变量
        /// <summary>
        /// 字节片段大小
        /// </summary>
        private int blockSize;

        /// <summary>
        /// 传输队列
        /// </summary>
        private Dictionary<string, FileTransmission> transmission;
        #endregion

        public Dictionary<string, FileTransmission> Transmission { get { return transmission; } }

        #region 构造函数
        /// <summary>
        /// 创建一个文件传输发送端
        /// <see cref="TransportSender"/>
        /// </summary>
        /// <param name="info">文件传输服务信息</param>
        /// <param name="blockSize">字节片段大小</param>
        public TransportSender(XConnectionInformation info, int blockSize)
            : base(info)
        {
            this.blockSize = blockSize;
            transmission = new Dictionary<string, FileTransmission>();
            OnCommandMessage += new CommandMessageEventHandler(TransportSender_OnCommandMessage);
            OnConnect += new XConnectionConnectedEventHandler(TransportSender_OnConnect);

        }
        #endregion
        #region 实现


        /// <summary>
        /// 文件传输连接
        /// </summary>
        /// <param name="sender">事件源</param>
        /// <param name="xe">事件参数<see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/>
        /// </param>
        void TransportSender_OnConnect(object sender, XConnectionEventArgs xe)
        {
            Console.WriteLine("{0}连接进入！", xe.Connection.RemoteEndPoint.ToString());

        }

        /// <summary>
        /// 文件传输请求
        /// </summary>
        /// <param name="sender">事件源</param>
        /// <param name="xe">事件参数<see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/>
        /// </param>
        /// <param name="msg">传输请求</param>
        void TransportSender_OnCommandMessage(object sender, XConnectionEventArgs xe, CommandMessage msg)
        {
            switch (msg.Option)
            {
                case TransportOption.GET_FILE:
                    Console.WriteLine("{0}请求文件:{1}", xe.Connection.RemoteEndPoint.ToString(), msg.Arguments[0].ToString());
                    string fileName = msg.Arguments[0];
                    if (File.Exists(fileName))
                    {
                        Console.WriteLine("文件存在！");
                        if(!transmission.ContainsKey(xe.Connection.RemoteEndPoint.ToString()))
                        {
                            Console.WriteLine("找到文件（{0}）开始发送！", fileName);
                            FileTransmission ft = new FileTransmission(xe.Connection, new NetFile(fileName, blockSize,Convert.ToInt64(msg.Arguments[1])));
                            ft.OnError += new FileTransmissionErrorHandler(ft_OnError);
                            ft.OnFinished += new FinishedEventHandler(ft_OnFinished);
                            transmission.Add(xe.Connection.RemoteEndPoint.ToString(), ft);
                            ft.Send();
                        }
                       
                    }
                    else
                    {
                        Console.WriteLine("文件不存在！");
                        xe.Connection.Send(new CommandMessage(TransportOption.FILE_NOT_FOUND));
                    }
                    break;
                 
            }
        }

        /// <summary>
        /// 一个文件传输完成
        /// </summary>
        /// <param name="sender">事件源</param>
        void ft_OnFinished(object sender)
        {

            IXConnection connection = (sender as FileTransmission).Connection;
            string key = connection.RemoteEndPoint.ToString();
            if (transmission.ContainsKey(key))
            {
                FileTransmission ft = transmission[key];
                Console.WriteLine("文件{0}传输至{1}完成！", ft.NetFile.RemoteFile, key);
                transmission.Remove(key);
                ft.OnError -= new FileTransmissionErrorHandler(ft_OnError);
                ft.OnFinished -= new FinishedEventHandler(ft_OnFinished);
                ft.Dispose();
                Console.WriteLine("移除已完成的文件！！！" + key + "//" + transmission.Count);
            }
        }

        /// <summary>
        /// 文件传输发生错误
        /// </summary>
        /// <param name="sender">事件源</param>
        /// <param name="e">异常信息
        /// <see cref="HuaBo.Net.FileTransport.FileTransmissionErrorEventArgs"/>
        /// </param>
        void ft_OnError(object sender, FileTransmissionErrorEventArgs e)
        {
            Console.WriteLine("传输发生异常！！！"+e.InnerException.ToString());
            IXConnection connection = (sender as FileTransmission).Connection;
           
            string key = connection.RemoteEndPoint.ToString();
            if (transmission.ContainsKey(key))
            {
                FileTransmission ft = transmission[key];
                transmission.Remove(key);
                ft.Dispose();
            }
        }
        #endregion
    }


}
