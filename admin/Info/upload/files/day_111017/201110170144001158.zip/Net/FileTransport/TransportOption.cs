﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HuaBo.Net.FileTransport
{
    public class TransportOption
    {
        public const string GET_BLOCK = "getBlock";
        public const string RE_GET_BLOCK = "reGetBlock";
        public const string GET_FILE = "getFile";
        public const string WAIT = "wait";
        public const string GO_ON = "goOn";
        public const string FINISH = "finish";
        public const string READY = "ready";
        public const string FILE_NOT_FOUND = "fileNotFound";
    }
}
