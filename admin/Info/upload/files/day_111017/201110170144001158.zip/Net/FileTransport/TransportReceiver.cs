﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.IO;

using HuaBo.Collections;
using HuaBo.Net.Sockets;
using HuaBo.Net.Sockets.Base;
using HuaBo.Net.Sockets.Message;

namespace HuaBo.Net.FileTransport
{
    /// <summary>
    /// 
    /// </summary>
    public class TransportReceiver:XClient
    {

        /// <summary>
        /// 传输任务列表
        /// </summary>
        private TransmissionTask task;
        /// <summary>
        /// 文件传输管道
        /// </summary>
        private FileTransmission fileTransmission;
        
        /// <summary>
        /// 获取文件传输管道
        /// </summary>
        public FileTransmission Transmission { get { return fileTransmission; } }
        /// <summary>
        /// 构造函数<see cref="TransportReceiver"/>
        /// </summary>
        /// <param name="info">文件传输管道信息</param>
        public TransportReceiver(XConnectionInformation info)
            : base(info)
        {
            this.task = new TransmissionTask();
            fileTransmission = new FileTransmission(this);
            fileTransmission.OnFinished += new FinishedEventHandler(fileTransmission_OnFinished);
            OnConnect += new XConnectionConnectedEventHandler(TransportReceiver_OnConnect);
            OnCommandMessage += new CommandMessageEventHandler(TransportReceiver_OnCommandMessage);
        }
        public void AddTask(TransmissionTask task)
        {
            foreach (TransportInfo tpinfo in task.Items.Values)
            {
                AddTransport(tpinfo);
            }
        }
        public event FinishedEventHandler OnFinished;
        public event EventHandler OnFinishedAll;
        public void RemoveTask(TransmissionTask task)
        {
            foreach (TransportInfo tpinfo in task.Items.Values)
            {
                RemoveTransport(tpinfo);
            }
        }

        public void AddTransport(TransportInfo tpinfo)
        {
            if (!this.task.Items.ContainsKey(tpinfo.RemoteFile))
            {
                this.task.Items.Add(tpinfo.RemoteFile, tpinfo);
            }
        }

        public void RemoveTransport(TransportInfo tpinfo)
        {
            if (this.task.Items.ContainsKey(tpinfo.RemoteFile))
            {
                if (this.task.CurrentItem.RemoteFile == tpinfo.RemoteFile)
                {
                    if (!task.CurrentItem.Finished)
                    {
                        Stop();
                        fileTransmission.Stop();
                    }
                    File.Delete(tpinfo.TargetFile);
                }
                this.task.Remove(tpinfo.RemoteFile);
            }
        }

        public TransportInfo CurrentTransport { get { return task.CurrentItem; } }
        public int TaskCount { get { return task.Items.Count; } }
        public SerializableDictionary<string ,TransportInfo> Task { get { return task.Items; } }
        /// <summary>
        /// 一个传输任务完成
        /// </summary>
        /// <param name="sender">事件源</param>
        void fileTransmission_OnFinished(object sender)
        {
            
            task.CurrentItem.Finished = true;
            if (OnFinished != null)
            {
                OnFinished(this);
            }
            Console.WriteLine(task.CurrentItem + "传输完成！");
            fileTransmission.Stop();
             TransportInfo tpinfo = task.Next();
            
             if (tpinfo != null)
             {
                 fileTransmission.NetFile = new NetFile(tpinfo);
                 Console.WriteLine("请求传输{0}", tpinfo);
                 fileTransmission.Receive();
             }
             else
             {
                 Console.WriteLine("全部文件传输完成！");
                 //TODO全部完成！
                 if (OnFinishedAll != null)
                 {
                     OnFinishedAll(this,new EventArgs());
                 }
             }
        }

        /// <summary>
        /// Transports the receiver_ on command message.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="xe">The <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/> instance containing the event data.</param>
        /// <param name="msg">The MSG.</param>
        void TransportReceiver_OnCommandMessage(object sender, XConnectionEventArgs xe, CommandMessage msg)
        {
            Console.WriteLine(msg.Option);
            switch (msg.Option)
            {
                case TransportOption.READY:
                    fileTransmission.Start();    
                break;
            }
        }

        /// <summary>
        /// Handles the OnConnect event of the TransportReceiver control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="xe">The <see cref="HuaBo.Net.Sockets.Base.XConnectionEventArgs"/> instance containing the event data.</param>
        void TransportReceiver_OnConnect(object sender, XConnectionEventArgs xe)
        {
           
            Receive();
        }

        public void Receive()
        {
          
            TransportInfo tpinfo = task.Next();
            Console.WriteLine(tpinfo == null ? "没有文件要传输！" : "传输" + tpinfo.RemoteFile);
            if (tpinfo != null)
            {
                fileTransmission.NetFile = new NetFile(tpinfo);
                Console.WriteLine("请求文件：" + tpinfo.RemoteFile);
                fileTransmission.Receive();

            }
        }

        public void Reset()
        {
            fileTransmission.Stop();
        }
    }
}
