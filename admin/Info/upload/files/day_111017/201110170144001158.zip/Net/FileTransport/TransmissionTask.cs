﻿using System;
using System.Collections.Generic;
using System.Text;

using HuaBo.Collections;
namespace HuaBo.Net.FileTransport
{
    /// <summary>
    /// TransmissionTask表示一组传输任务(可序列化)
    /// </summary>
    public class TransmissionTask
    {
        /// <summary>
        /// 传输任务队列
        /// </summary>
        public SerializableDictionary<string, TransportInfo> Items;
        /// <summary>
        /// 当前正在传输的任务
        /// </summary>
        private TransportInfo _currentItem;
        /// <summary>
        /// 获取当前正在传输的任务
        /// </summary>
        public TransportInfo CurrentItem { get { return _currentItem; } }
        /// <summary>
        /// 构造函数 
        /// <see cref="TransmissionTask"/>
        /// </summary>
        public TransmissionTask()
        {
            Items = new SerializableDictionary<string, TransportInfo>();
        }

        /// <summary>
        /// 下一个传输任务
        /// </summary>
        /// <returns>传输任务,如到达末尾返回null</returns>
        public TransportInfo Next()
        {
            TransportInfo tpinfo = null;
            _currentItem = null;
            if (Items.Count != 0)
            {
                foreach (string key in Items.Keys)
                {
                    tpinfo = Items[key];
                    Console.WriteLine("文件{0},传输状态:{1}", tpinfo.RemoteFile, tpinfo.Finished);
                    if (!tpinfo.Finished)
                    {
                        _currentItem = tpinfo;
                        break;
                    }
                }
            }
            return _currentItem;
        }

        /// <summary>
        /// 添加一个传输任务
        /// </summary>
        /// <param name="tpinfo">传输任务</param>
        public void Add(TransportInfo tpinfo)
        {
            //TODO重复键值应该抛出异常通知用户
            if (Items.ContainsKey(tpinfo.RemoteFile)) return;
            Items.Add(tpinfo.RemoteFile, tpinfo);
        }
       

        /// <summary>
        /// 移除指定传输任务
        /// </summary>
        /// <param name="key">传输任务名</param>
        public void Remove(string key)
        {
            if (Items.ContainsKey(key))
            {
                if (_currentItem != null && _currentItem.RemoteFile == key)
                {
                    _currentItem = null;
                }
                Items.Remove(key);
            }
        }
    }
}
