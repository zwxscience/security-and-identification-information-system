﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HuaBo.Net.FileTransport
{
    public delegate void BlockFinishedEventHandler(object sender, BlockFinishedEventArgs e);
    public delegate void FinishedEventHandler(object sender);
    public delegate void FileTransmissionErrorHandler(object sender, FileTransmissionErrorEventArgs e);

    public class BlockFinishedEventArgs : EventArgs
    {
        public int BlockIndex { get; set; }
        public BlockFinishedEventArgs(int blockIndex) { this.BlockIndex = blockIndex; }
    }

    
    public class FileTransmissionErrorEventArgs : EventArgs
    {
        public Exception InnerException { get; set; }
        public FileTransmissionErrorEventArgs(Exception ex) { this.InnerException = ex; }
    }
}
