﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using HuaBo.Net.Sockets.Message;

namespace HuaBo.Net.FileTransport
{
    public class NetFile:IDisposable
    {
        #region 成员变量
        /// <summary>
        /// 文件区块大小
        /// </summary>
        private int _blockSize;
        /// <summary>
        /// 文件总块数
        /// </summary>
        private int _totalBlock;
       
        /// <summary>
        /// 文件总字节数
        /// </summary>
        private long _totalBytes;
        /// <summary>
        /// 文件已传输字节数
        /// </summary>
        private long _transprotedBytes;
        /// <summary>
        /// 文件已完成字节数
        /// </summary>
        private long _finishedBytes;
        /// <summary>
        /// 文件最后一个区块大小
        /// </summary>
        private int _lastBlockSize;

        private FileStream fileStream;

        private string _remoteFile;
        private string _targetFile;


        private Dictionary<int, ByteMessage> ioBuffer;

        public static int MaxIOBuffer = 10;
        #endregion
        #region get/set

        public string RemoteFile { get { return _remoteFile; } }
        public string TargetFile { get { return _targetFile; } }

        public int BlockSize
        {
            get { return _blockSize; }
        }
        public long TotalBytes
        {
            get { return _totalBytes; }
        }
        public long TransprotedBytes
        {
            get { return _transprotedBytes; }
            set { _transprotedBytes = value; }
        }
        public long FinishedBytes
        {
            get { return _finishedBytes; }
        }
        public int LastBlockSize
        {
            get { return _lastBlockSize; }
        }
        public int TotalBlock{get{return _totalBlock;}}
       
        public int FinishedBlock
        {
            get { if (Finished) { return _totalBlock; } return (int)(_transprotedBytes / (long)_blockSize); }
        }
        public bool Finished
        {
            get { return _totalBytes == _transprotedBytes; }
        }

        #endregion

        public NetFile(FileStream fs ,int blockSize,long finishedBytes)
        {
            _remoteFile = fs.Name;
            _lastBlockSize=0;
            _finishedBytes=finishedBytes;
            _transprotedBytes = finishedBytes;
            
            fileStream=fs;
            _blockSize = blockSize;
            _totalBytes=fileStream.Length;
            _totalBlock=(int)(_totalBytes/(long)_blockSize);
            if(((long)_totalBlock*(long)_blockSize)!=_totalBytes)
            {
                _lastBlockSize =((int)(_totalBytes-((long)_totalBlock*(long)_blockSize)));
                _totalBlock+=1;
            }
            ioBuffer = new Dictionary<int,ByteMessage>();
        }

        public NetFile(string filePath,int blockSize,long finishedBytes):this(new FileStream(filePath,FileMode.OpenOrCreate,FileAccess.Read),blockSize,finishedBytes){}

        public NetFile(TransportInfo tpInfo)
        {
            
            _remoteFile = tpInfo.RemoteFile;
            _targetFile = tpInfo.TargetFile;
              _lastBlockSize = 0;
              string dir = Path.GetDirectoryName(tpInfo.TargetFile);
            if(!Directory.Exists(dir))
                Directory.CreateDirectory(dir);
              fileStream = new FileStream(tpInfo.TargetFile,FileMode.OpenOrCreate,FileAccess.ReadWrite);
             
              _finishedBytes = fileStream.Length;
              _transprotedBytes = fileStream.Length;
              Console.WriteLine("%%%%$$^#^#$^#$^#$^#^#^#^#^#^#^#^#$^#^#" + _transprotedBytes);
            _blockSize = tpInfo.BlockSize;
            _totalBytes = tpInfo.TotalBytes;
            _totalBlock=(int)(_totalBytes/(long)_blockSize);
            if(((long)_totalBlock*(long)_blockSize)!=_totalBytes)
            {
                _lastBlockSize =((int)(_totalBytes-((long)_totalBlock*(long)_blockSize)));
                _totalBlock+=1;
            }
            ioBuffer = new Dictionary<int,ByteMessage>();
        }

        public ByteMessage Read(int blockIndex){
            if(ioBuffer.ContainsKey(blockIndex))return ioBuffer[blockIndex];
            if(ioBuffer.Count==MaxIOBuffer) ioBuffer.Clear();
            byte[] data = new byte[_blockSize];
            int dataLen=0;
            lock(fileStream){
                fileStream.Position = (long)blockIndex*(long)_blockSize;
                dataLen = fileStream.Read(data,0,_blockSize);
            }
            if(data.Length!=dataLen){
                byte[] old = data;
                data = new byte[dataLen];
                Array.Copy(old,data,dataLen);
            }
            ByteMessage msg = new ByteMessage(data,blockIndex);
            _transprotedBytes+=msg.Length;
            ioBuffer.Add(blockIndex,msg);
            return msg;
        }
        public void Write(ByteMessage msg){
            if(ioBuffer.Count==MaxIOBuffer){
                WriteBuffer();
            }
            if (ioBuffer.ContainsKey(msg.Index))
            {
                ioBuffer.Remove(msg.Index);
            }
            ioBuffer.Add(msg.Index,msg);
            _transprotedBytes+=msg.Length;
            if(Finished){
                WriteBuffer();
            }
        }

        public void Dispose(){
            if(fileStream!=null){
                try{
                    fileStream.Close();
                }finally{
                    fileStream=null;
                }
            }
            if(ioBuffer!=null)
            ioBuffer.Clear();
            ioBuffer=null;
        }

        private void WriteBlock(ByteMessage msg){
            lock(fileStream){
                fileStream.Position=(long) msg.Index*(long)_blockSize;
                fileStream.Write(msg.Data,0,msg.Length);
                if(msg.Length==_lastBlockSize){
                    fileStream.Close();
                }
            }
        }
        private void WriteBuffer(){
            foreach(ByteMessage msg in ioBuffer.Values){
                WriteBlock(msg);
            }
            ioBuffer.Clear();
        }

    }
}
